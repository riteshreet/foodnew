<?php  
require_once('classes/Utility.php');
include_once('language/lang_en.php');

?>
<!-- Left Panel -->
  <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a href="dashboard.php" class="navbar-brand" ><?php echo $language['food_shastra'];?></a>
                <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="dashboard.php"> <i class="menu-icon fa fa-dashboard"></i><?php echo $language['dashboard'];?>
						</a>
                    </li>
					<li>
                        <a href="menu_category.php"> <i class="menu-icon fa fa-list-alt"></i><?php echo $language['menu_category'];?></a>
                    </li>
					<li>
                        <a href="menu_item.php"> <i class="menu-icon fa fa-file-text-o"></i><?php echo $language['menu_item'];?></a>
                    </li>
					<li>
                        <a href="ingredients.php"> <i class="menu-icon fa fa-file-text-o"></i><?php echo $language['menu_ingredients'];?></a>
                    </li>
					<li>
                        <a href="app_user.php"> <i class="menu-icon fa fa-user"></i><?php echo $language['app_user'];?></a>
                    </li>
					<li>
                        <a href="delivery_boy.php"> <i class="menu-icon fa fa-user"></i><?php echo $language['delivery_boy'];?></a>
                    </li>
					<li>
                        <a href="city.php"> <i class="menu-icon fa fa-user"></i><?php echo $language['city'];?></a>
                    </li>
                   
                    <h3 class="menu-title"><?php echo $language['notification'];?></h3> <!-- /.menu-title -->

					<li>
                        <a href="send_notification.php"> <i class="menu-icon fa fa-bell"></i><?php echo $language['send_notification'];?></a>
                    </li>
					<li>
                        <a href="android_notification.php"> <i class="menu-icon fa fa-check"></i><?php echo $language['android_notification'];?></a>
                    </li>
					<li>
                        <a href="ios_notification.php"> <i class="menu-icon fa fa-check"></i><?php echo $language['ios_notification'];?></a>
                    </li>
					
					
					<h3 class="menu-title"><?php echo $language['currency_small'];?></h3> <!-- /.menu-title -->
					<li>
                    <?php 
                        $sql_cur = mysqli_query($conn,"SELECT * FROM `food_user`");
                       
                        $currancy =mysqli_fetch_array($sql_cur);
                    ?>
                            <a  onchange="mycurrency()"><i class="menu-icon fa fa-money" ></i><?php echo $language['currency_small'];?>
                            <select id="select_currency" class="form-control">
                                <?php 
                                if($currancy['currency'] != "")
                                { ?>
                                    <option value="<?php echo $currancy['currency']; ?>" selected><?php echo $currancy['currency']; ?></option>
                            <?php   }
                                else
                                { ?>
                                    <option value="$"><?php echo "USD - $"; ?></option>
                                <?php }
                                ?>
                                
                                <?php require_once('currancy.php');  ?>
                            </select></a>
                    </li>
					
                 </ul>
			</div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

	<script>

function mycurrency() {
    var txt;
    if (confirm("Are you sure you want to change currancy?")) {
            var select_currency = document.getElementById("select_currency").value;
    
	jQuery.ajax({
	type: 'post',
	url: 'ajax/changecurrency.php',
	data:'select_currency='+select_currency,
	
	success: function (response) {
       
	jQuery("#ddd").html(response);

 }
 });
    } else {
       
    }
    
}

	


	

</script>