<?php
require_once('classes/Utility.php');

if(isset($_POST['view'])){
  
// $con = mysqli_connect("localhost", "root", "", "notif");

if($_POST["view"] != '')
{
   $update_query = "UPDATE set_order_detail SET notify=2  where notify=1";
   mysqli_query($conn, $update_query);
}

$query = "SELECT * FROM set_order_detail WHERE notify=1";
$result = mysqli_query($conn, $query);
$output = '';
if(mysqli_num_rows($result) > 0)
{

  $output .= '
 
  <a href="dashboard.php">
  <strong>You have '.mysqli_num_rows($result).' New Order</strong>
  </a>
 

  ';
}

else{
 $output .= '
 
  <a href="dashboard.php">
  <strong>You have '.mysqli_num_rows($result).' New Order</strong>
  </a>
  

  ';
}

$status_query = "SELECT * FROM set_order_detail WHERE notify=1";
$result_query = mysqli_query($conn, $status_query);
$count = mysqli_num_rows($result_query);

$data = array(
   'notification' => $output,
   'unseen_notification'  => $count
);

echo json_encode($data);
}
?>