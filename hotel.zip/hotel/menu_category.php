<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->

<?php 
@session_start();
if(!isset($_SESSION['uid'])){
   echo "<script>window.location='index.php'</script>";
    session_destroy();
}
include("classes/CategoryClass.php");
include_once('classes/Utility.php');
include_once('language/lang_en.php');
require_once('header_link.php'); 
include_once('pagination.php');
$page_limit=10;
if (isset($_GET['page'])) {
  $page=$_GET['page'];
}
else {
  $page=1;
}
if ($page=='' || $page==1) {
  $page1=0;
}
else{
  $page1=($page*$page_limit)-$page_limit;
}
if(isset($_GET['serach']) && $_GET['serach'] != ""){
	$row=CategoryClass::getallcat_serach($_GET['serach'],$page1,$page_limit);
	$getTotalcategory=CategoryClass::getTotalcategory_serach($_GET['serach']);  
}else{
	$row=CategoryClass::getallcat($page1,$page_limit);
	$getTotalcategory=CategoryClass::getTotalcategory();  	
}
 

?> 


<?php require_once('side_menu.php'); ?> 


<div id="right-panel" class="right-panel">
	<?php require_once('header.php'); ?> 
        <!-- Header-->
	
        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo $language['menu_category']; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active"><?php echo $language['menu_category']; ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

	<?php
if(isset($_POST["add_menu_cat"]))
{
	$objCategory=new CategoryClass();
    $objCategory->cat_name=$_POST['cat_name'];
    $img_file=$_FILES['file']['name'];
    $temp_img_file = explode(".", $_FILES["file"]["name"]);
    if(end($temp_img_file) == 'png' || end($temp_img_file) == 'jpeg' || end($temp_img_file) == 'JPG' || end($temp_img_file) == 'jpg'){
        $newfilename = "category_". round(microtime(true)) . '.' . end($temp_img_file);
        $objCategory->cat_icon=$newfilename;
        $tpath1='images/menu_cat_icon/'.$newfilename;
        $objMessage=CategoryClass::insertNewCategory($objCategory);                   
        if ($objMessage->status==1) { 
           move_uploaded_file($_FILES["file"]["tmp_name"], "images/menu_cat_icon/" . $newfilename);
          echo "<script>window.location.href='menu_category.php';</script>";  
        }
        else{
            echo "<script>window.location.href='menu_category.php';</script>";
        }  
    }else{
        ?>
        <script>alert("plz select png,jpg,jpeg image");</script>
        <?php
         echo "<script>window.location.href='menu_category.php';</script>";
    }
   
}
if(isset($_POST['editcategory'])){
    $obj=new CategoryClass();
    $id = $_POST['id'];
    $objCategory=CategoryClass::getcategory($id);
    $obj->cat_name=($objCategory->cat_name==$_POST['name']) ? $objCategory->cat_name : $_POST['name'];
    $image=$_FILES['file']['name'];
    $Oldimg = $_POST['image'];
    if (strlen($image)!=0) {
      $temp_img_file = explode(".", $_FILES["file"]["name"]);
      $newfilename = "category_".round(microtime(true)) . '.' . end($temp_img_file);
      if(end($temp_img_file) == 'png' || end($temp_img_file) == 'jpeg' || end($temp_img_file) == 'JPG' || end($temp_img_file) == 'jpg'){
      $obj->cat_icon=$newfilename;
      $tpath1='images/menu_cat_icon/'.$newfilename;
      $objMessage=CategoryClass::updateCategory($obj,$id);
      if($objMessage->status==1){
        $file_path="images/menu_cat_icon/$Oldimg";
          unlink($file_path);
         move_uploaded_file($_FILES["file"]["tmp_name"], "images/menu_cat_icon/" . $newfilename);
         echo "<script>window.location.href='menu_category.php';</script>";
      }
      else{
       echo "<script>window.location.href='menu_category.php';</script>";
      }
      }else{
        ?>
        <script>alert("plz select png,jpg,jpeg image");</script>
        <?php
         echo "<script>window.location.href='menu_category.php';</script>";
        }
    }
    else{
      $obj->cat_icon=$Oldimg;
      $objMessage=CategoryClass::updateCategory($obj,$id);
      if($objMessage->status==1){
         echo "<script>window.location.href='menu_category.php';</script>";
      }
      else{
        MessageClass::showMessage($objMessage);
      }
    }
}

if(isset($_GET['app_category_did']))
	{
		$app_category_did =$_GET['app_category_did'];
		
		$sql_cat = mysqli_query($conn,"SELECT * FROM `food_category` where id = $app_category_did");
	
		$row_cat = mysqli_fetch_array($sql_cat);
		echo $cat_icon = $row_cat['cat_icon']; 
		unlink("images/menu_cat_icon/$cat_icon");

		$sql_menu = mysqli_query($conn,"SELECT * FROM `food_menu` where `category` = $app_category_did");
		
		$row_menu =mysqli_fetch_array($sql_menu);
		$menu_image = $row_menu['menu_image'];
		unlink("images/menu_item_icon/$menu_image");
		
		$menu_sqll = mysqli_query($conn,"DELETE FROM `food_menu` WHERE `category`=".$app_category_did."");
		
		
		$ingredients_sql = mysqli_query("DELETE FROM `food_ingredients` WHERE `category`=".$app_category_did."");

		
		$cat_sql = mysqli_query($conn,"DELETE FROM `food_category` WHERE `id`=".$app_category_did."");
		
		echo "<script>window.location.href='menu_category.php';</script>";
	}
?>
<div class="content mt-3">
	<div class="animated">
			<div class="breadcrumbs">  
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#myModal"><?php echo $language['add_menu_category']; ?></button></h1>
                    </div>
                </div>
	        </div>
			<div class="content mt-3">
		        <div class="animated fadeIn">
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									
						            <div class="col-sm-8">
						                <div class=" float-left">
						                   	<strong class="card-title"><?php echo $language['data_table']; ?></strong> 
						                </div>
						            </div>
						            <div class="col-sm-4">
						                <div class="p">
						                	<div class="row">
						                		<form method="get">
						                		<div class="col-md-8">
						                			<?php if(isset($_GET['serach'])){
						                			?>
						                			<input required="" value="<?php echo $_GET['serach']?>" type="text" name="serach" class="form-control">
						                			<?php
						                			} else { ?>
						                    		<input required="" type="text" name="serach" class="form-control">
						                    		<?php } ?>
						                    	</div>
						                    	<div class="col-md-2">
						                    		<?php if(isset($_GET['serach'])){
						                    		?>
						                    		<a href="menu_category.php" class="btn btn-primary btn-md"><?php echo $language['reset'];?></a>
						                    		<?php
						                    		} else { ?>
						                    		<button class="btn btn-primary btn-md" type="submit"><?php echo $language['search_btn'];?></button>
						                    		<?php } ?>
						                    	</div>
						                    	</form>
						                	</div>
						                </div>
						            </div>
	       
								</div>
								<div class="card-body">
									<?php
									if ($row)
									{
									?>
									<table class="table table-striped table-bordered">
										<thead>
											<tr>
												<th><?php echo $language['id']; ?></th>
												<th><?php echo $language['menu_name']; ?></th>
												<th><?php echo $language['menu_icon']; ?></th>
												<th><?php echo $language['action']; ?></th>
											</tr>
										</thead>
										<tbody>
											<?php
											$t = 1;
												for($i=0;$i<count($row);$i++) 
												{ ?>
														<tr>
														<td><?php echo $t;?></td>		
														<td><?php echo  $row[$i]->cat_name; ?></td>
														<td><img  class="img-fluid" src="images/menu_cat_icon/<?php echo  $row[$i]->cat_icon; ?>" width="80px"></td>
														
														<td>
														<?php if($GLOBALS['button'] == 'YES') { ?>
															<a href=""  onClick="return confirm('This function is currently disable as it is only a demo website, in your admin it will work perfect')"  class="btn btn-md btn-danger"><?php echo $language['delete_btn']; ?></a>

															<a href="" class="btn btn-md btn-info" onClick="return confirm('This function is currently disable as it is only a demo website, in your admin it will work perfect')" ><?php echo $language['edit_btn']; ?></a>
														<?php } else { ?>
															<a  href="menu_category.php?app_category_did=<?php echo $row[$i]->id; ?>" onclick="return confirm('Are you sure you want to delete?')" class="btn btn-md btn-danger "><?php echo $language['delete_btn']; ?></a>

															<a id="mySelect" onclick="getcategory(<?php echo  $row[$i]->id; ?>)" class="btn btn-md btn-info" data-toggle="modal" data-target="#cat_edit_Modal"><?php echo $language['edit_btn']; ?></a>
														<?php } ?>
														</td>
																
														</tr>
												<?php $t++;
												 } ?>
										</tbody>
									</table>
									
									<div class="">
									<?php
					                if(isset($_GET['page']))
					                {
					                    $select=$_GET['page'];
					                }
					                else
					                {
					                    $select=1;
					                }
					                if(isset($_GET['serach'])){
					                   $url="menu_category.php?serach=".$_GET['serach']."&"; 
					                }else{
					                  $url="menu_category.php?";  
					                }
					               
					                echo pagination($getTotalcategory,10,$select,$url);
					            	?>
									</div>
									<?php 
									}else
									{
										echo "Data not Found";
									}
									?>
								</div>
								
							</div>
							
						</div>
					</div>
			</div>
		</div>
</div>
	<div class="modal fade" id="myModal" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title"><?php echo $language['add_menu_category']; ?></h5>
							<button type="button" class="close" data-dismiss="modal">&times;</button>
						</div>
						<div class="modal-body">
							<form name="menu_form_category" action="" method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label><?php echo $language['category_name']; ?></label>
									<input type="text" class="form-control" placeholder="<?php echo $language['category_name']; ?>" name="cat_name" required>
								</div>
								<div class="form-group">
									<label><?php echo $language['category_icon']; ?></label>
									<input type="file" class="form-control"  name="file" required  accept="image/*">
								</div>
								<div class="col-md-12">
									<div class="col-md-6">
										<input type="submit" name="add_menu_cat"  class="btn btn-primary btn-md form-control" value="<?php echo $language['add_btn']; ?>">
									</div>
									<div class="col-md-6">
										<input type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="<?php echo $language['close_btn']; ?>">
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="modal fade" id="cat_edit_Modal" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<form action="" method="post" enctype="multipart/form-data">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title"><?php echo $language['edit_menu_category']; ?></h5>
								<button type="button" class="close" data-dismiss="modal">&times;</button>
							</div>
							<div class="modal-body" id="cat_edit_form">
								 <div id="showgallery">	
							</div>

						<div class="col-md-12">
							<div class="col-md-6">
								<input type="submit" name="editcategory"  class="btn btn-primary btn-md form-control" value="<?php echo $language['edit_btn']; ?>">
							</div>
							<div class="col-md-6">
								<input type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="<?php echo $language['close_btn']; ?>">
							</div>
						</div>
					</div>
					</form>
				</div>
			</div>
		</div>
	</div>
<script>
    function getcategory(id) {
        
        var url='ajax/edit_category.php?id='+id;
        
        $.ajax({
            url: url,
            type: 'GET',
            success: function (data) {
               if (data)
            {
                $('#showgallery').replaceWith($('#showgallery').html(data));
            }
            else
            {
                alert('error');
            }
                                    
            },
            error: function(e) {
                alert('Error: '+e);
            }
        });
    }
</script>
  <?php require_once('footer_link.php'); ?> 