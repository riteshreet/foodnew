<?php
@session_start();
include_once('language/lang_en.php');

include_once('classes/AdminClass.php');

if (isset($_SESSION['uid'])) {
  echo "<script>window.location='dashboard.php'</script>";
    
}
?>
<?php 

require_once('header_link.php'); ?> 
   <?php
      if (isset($_POST['login'])) {
   
     
        if (AdminClass::authenticateAdmin($_POST['username'],$_POST['password'])) {
          
        
          header('location:dashboard.php');
        }
        else{
          ?><div class="alert alert-danger text--center" role="alert"><strong><i class="fas fa-exclamation-triangle"></i></strong> <?php echo $language['invalid_username_or_password']; ?></div><?php
        }
      }
      ?>
<body class="bg-dark">


    <div class="sufee-login d-flex align-content-center flex-wrap">
        <div class="container">
            <div class="login-content">
                <div class="login-logo">
                   <h4 style="color:#ffffff"><?php echo $language['food_shastra']; ?> <font style="color:#bfbfbf"><?php echo $language['admin'];?></font></h4>
               </div>
                <div class="login-form">
                    <form method="post">
                        <div class="form-group">
                            <label><?php echo $language['email_address']; ?> </label>
                            <input name="username" type="text" class="form-control" placeholder="Email">
                        </div>
                        <div class="form-group">
                            <label><?php echo $language['password']; ?></label>
                            <input name="password" type="password" class="form-control" placeholder="Password">
                        </div>
                      
			         <button name="login" type="submit" class="btn btn-success btn-flat m-b-30 m-t-30"><?php echo $language['sign_in']; ?></button>
                     
		     
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script src="assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>


</body>
</html>
