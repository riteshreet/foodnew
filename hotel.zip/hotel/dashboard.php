<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<?php
@session_start();
if(!isset($_SESSION['uid'])){
    echo "<script>window.location='index.php'</script>";
    session_destroy();
}
include_once('classes/DashboardClass.php');
include_once('classes/Utility.php');
include_once('language/lang_en.php');
require_once('header_link.php'); 
include_once('pagination.php');
$page_limit=10;
if (isset($_GET['page'])) {
  $page=$_GET['page'];
}
else {
  $page=1;
}
if ($page=='' || $page==1) {
  $page1=0;
}
else{
  $page1=($page*$page_limit)-$page_limit;
}
$res=DashboardClass::getAllOrder($page1,$page_limit);
$getTotalOrder=DashboardClass::getTotalOrder();   

?> 
<body>

<?php require_once('side_menu.php'); ?> 
       
<?php
if(isset($_POST['assign']))
{
	require_once('assign.php');
	
}
?>
    
<div id="right-panel" class="right-panel">
	<?php require_once('header.php'); ?> 
        <!-- Header-->
        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo $language['dashboard'];?></h1>
					</div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active"><?php echo $language['dashboard'];?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>	
		<div class="modal fade" id="assign_order">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">						
						<h4 class="modal-title"><?php  echo $language['assign_order_delivery_Boy'];?></h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
					</div>
					<div class="modal-body" >
					 <div class="panel panel-inverse" data-sortable-id="form-validation-1">
						<div class="panel-body panel-form">
							<form class="form-horizontal form-bordered" data-parsley-validate="true" method="post" action="" name="demo-form">
								<div class="form-group" id="order_assign">

								</div>

								<div class="modal-footer">
									<a href="javascript:;" class="btn btn-sm btn-white" data-dismiss="modal"><?php echo $language['close_btn']; ?></a>
									<input type="submit" class="btn btn-primary" name="assign" value="<?php echo $language['assign_btn']; ?>" />
								</div>
							</form>
						</div>
					</div>
					</div>
				</div>
			</div>
		</div>		
		
		<div class="content mt-3">
			<div class="col-sm-6 col-lg-4">
                <div class="card text-white bg-flat-color-1">
                    <div class="card-body pb-0">
					  	<?php $count_date = DashboardClass::count_todayorder();?>
						 <h4 class="mb-0">
                        <?php echo $language['today_order']; ?>
                        </h4>
							<h1><?php echo $count_date; ?></h1>
						<div class="chart-wrapper px-3" style="height:70px;" height="70">
                            <canvas id="widgetChart4"></canvas>
                        </div>

                    </div>
                </div>
            </div>
			
			<div class="col-sm-6 col-lg-4">
                <div class="card text-white bg-flat-color-4">
                    <div class="card-body pb-0">
                       <h4 class="mb-0">
						<?php $count_total = DashboardClass::count_totalorder();?>
                        <h4 class="mb-0">
                          <?php echo $language['total_order']; ?>
                        </h4>
							<h1><?php echo $count_total; ?></h1>
						<div class="chart-wrapper px-3" style="height:70px;" height="70">
                            <canvas id="widgetChart4"></canvas>
                        </div>

                    </div>
                </div>
            </div>
			
			<div class="col-sm-6 col-lg-4">
                <div class="card text-white bg-flat-color-3">
                    <div class="card-body pb-0">
						<?php $count_totalaccpted = DashboardClass::count_accpetedorder();?>
                        <h4 class="mb-0">
                             <?php echo $language['total_accepted_order']; ?>
                        </h4>
							<h1><?php echo $count_totalaccpted; ?></h1>
						<div class="chart-wrapper px-3" style="height:70px;" height="70">
                            <canvas id="widgetChart4"></canvas>
                        </div>

                    </div>
                </div>
            </div>
		</div> <!-- .content -->
	
	<div class="content mt-3">
		<div class="animated">
			<div class="modal fade" id="myModal" role="dialog">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="modal-content modal-body" id="user_detail">
						
						</div>
						
					</div>
				</div>
			</div>
		</div>
			<div class="content mt-3">
				<div class="animated fadeIn">
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<strong class="card-title"><?php echo $language['data_table'];  ?></strong>
								</div>
								
									<table class="table table-striped table-bordered">
										<thead>
											<tr>
												<th>#</th>
												<th><?php echo $language['name'];  ?></th>
												<th><?php echo $language['address']; ?></th>
												<th><?php echo $language['more_details'];  ?></th>
												<th><?php echo $language['action'];  ?></th>
											</tr>
										</thead>
										<tbody>
												<?php 

												   if($res){
												   	$t = 1;
                        								for($i=0;$i<count($res);$i++){
															$res_user = Dashboardclass::app_user($res[$i]->user_id);
															for($j=0;$j<count($res_user);$j++){
														?>
														<tr>
															<td><?php echo  $t; ?></td>
															<td><?php echo  $res[$i]->name; ?></td>
															<td width="500px;"><?php echo  $res[$i]->address; ?></td>
															<td>
																<button id="mySelect" onclick="myFunction(<?php echo  $res[$i]->id; ?>)" type="button" class="btn btn-md btn-info" data-toggle="modal" data-target="#myModal"><?php echo $language['more_details_btn'];  ?></button>
															</td>
															<td>
															<?php 
															if ($res[$i]->order_status == 0)
															{ 
															?>
															<a class="btn btn-sm btn-success" onclick="confirmorder('<?php echo $res[$i]->id;?>')"><?php echo $language['accept'];?></a>
															<a onclick="rejectorder('<?php echo $res[$i]->id;?>')" class="btn btn-sm btn-info">
                                                    		Reject</a>																
															<a href="dashboard.php?delete_id=<?php echo $res[$i]->id; ?>"  class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to order delete?')"><?php echo $language['delete_btn'];  ?></a>
															<?php	
															} elseif ($res[$i]->order_status == 1) {
															?>
																<a href="#assign_order" onclick="assign_order('<?php echo  $res[$i]->id; ?>')" class="btn btn-success btn-md" data-toggle="modal"><?php echo $language['assign_order_btn'];  ?></a>
															<?php	
															} elseif ($res[$i]->order_status == 5) {
															?>
																<a href="#" class="btn btn-success btn-md"><?php echo $language['in_pickup_btn'];  ?></a>
															<?php	
															} elseif ($res[$i]->order_status == 2) {
															?>
																<a href="#" class="btn btn-danger btn-md"><?php echo $language['rejected_btn'];  ?></a>
																
															<?php	
															} elseif($res[$i]->order_status == 3) { 
															?>
															<a href="#" class="btn btn-md btn-info"><?php echo $language['out_of_delivery_btn']; ?></a>
																
															<?php	
															} elseif($res[$i]->order_status == 4) { 
															?>
																<button class="btn btn-md btn-danger" onclick="deleteorder('<?php echo $res[$i]->id?>')"><?php echo $language['delete_btn'];  ?></button>
															<?php
															}
															?>
															</td>

														</tr>
												<?php
												$t++;
														}
													}
												}
												?>
										</tbody>
									</table>
								</div>
								<?php
					                if(isset($_GET['page']))
					                {
					                    $select=$_GET['page'];
					                }
					                else
					                {
					                    $select=1;
					                }
					                $url="dashboard.php?";
					               
					                echo pagination($getTotalOrder,10,$select,$url);
					            ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
	<script>
	function confirmorder(id){
        $("#loading").show();
        $.ajax({
            type: "POST",
            url: 'ajax/confirmorder.php',
            data: {querystring: id},
            success: function (data) {
            	
                if (data == 1) {
                    $("#loading").hide();
                    alert("!!! Order Confirm Successfully !");
                    window.location='dashboard.php';
                }
                else
                {
                    $("#loading").hide();
                    alert("! Try again please!!!");
                }
            }
        });
    }
    function rejectorder(id){
        $("#loading").show();
        $.ajax({
            type: "POST",
            url: 'ajax/rejectorder.php',
            data: {querystring: id},
            success: function (data) {
                if (data == 1) {
                    $("#loading").hide();
                    alert("!!! Order has been Rejected !");
                    window.location='dashboard.php';
                }
                else
                {
                    $("#loading").hide();
                    alert("! Try again please!!!");
                }
            }
        });
    }
function myFunction(id) {
	
	jQuery.ajax({
	type: 'post',
	url: 'ajax/moredetalis.php',
	data:'id='+id,

	
	success: function (response) {
	
	jQuery("#user_detail").html(response);
	
 }
 });
	
}

function assign_order(id)
{
	$.ajax({
		type: "POST",
		url: "ajax/assign_order.php",
		data: 'id='+id,
		cache: false,
		success: function (data)
		{
			if (data)
			{
				$('#order_assign').replaceWith($('#order_assign').html(data));
			}
			else
			{

			}
		}
	});
}

function printDiv(divName) {

     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;

     window.print();
     //location.reload(true);

     document.body.innerHTML = originalContents;
     //$('#myModal').modal('hide');
     $('#myModal').modal('toggle');
}

</script>
<script>
function deleteorder(id)
    {
        var x = confirm("Are you sure want to delete ?");
        if(x) {
            var url='ajax/deleteorder.php?id='+id;
            
            $.ajax({
                url: url,
                type: 'GET',
                success: function (data) {
                  
                 window.location.reload();
              
            },
                error: function(e) {
                    alert('Error: '+e);
                }
            });
        }
    }
</script>
<?php require_once('footer_link.php'); ?> 