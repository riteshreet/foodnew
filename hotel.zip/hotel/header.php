        <?php include_once('./fetchupdate.php');
		
		include_once('language/lang_en.php');
		?>
        <header id="header" class="header">

            <div class="header-menu">
				<div class="col-sm-10">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                 </div>

                <div class="col-sm-2">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span style="color: red" class="label label-pill label-danger count" style="border-radius:10px;"></span> <i class="fa fa-bell"></i></a>

                  <div style="margin-bottom:25px" class="user-menu dropdown-menu dropdown-menu dropdown-menus" onclick="functionrefesh()"></div>
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">
                        </a>

                        <div class="user-menu dropdown-menu">
                                <a class="nav-link" href="myprofile.php"><i class="fa fa- user"></i><?php echo $language['my_profile']; ?></a>

                                <a class="nav-link" href="send_notification.php"><i class="fa fa- user"></i><?php echo $language['notification']; ?></a>
                                <a href="logout.php" ><i class="fa fa-power -off"></i><?php echo $language['logout']; ?></a>
                        </div>
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a class="dropdown-toggle" href="#" data-toggle="dropdown"  id="language" aria-haspopup="true" aria-expanded="true">
                            <i class="flag-icon flag-icon-us"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="language" >
                            <div class="dropdown-item">
                                <span class="flag-icon flag-icon-fr"></span>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-es"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-us"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-it"></i>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </header><!-- /header -->
       
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> 
 
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <script type="text/javascript">
    function play_sound() {
        var audioElement = document.createElement('audio');
        audioElement.setAttribute('src', 'serious-strike.mp3');
        audioElement.setAttribute('autoplay', 'autoplay');
        audioElement.load();
        audioElement.play();
    }
</script>
    <script>

 function functionrefesh(){
    
   $.ajax({
        url:"./fetchupdate.php",
        method:"POST",
        data:{},
         success:function(data){
            window.location.reload();
         }
   })
}
$(document).ready(function(){

// updating the view with notifications using ajax

function load_unseen_notification(view = '')

{

 $.ajax({

  url:"./fetch.php",
  method:"POST",
  data:{view:view},
  dataType:"json",
  success:function(data)

  {

   $('.dropdown-menus').html(data.notification);

   if(data.unseen_notification > 0)
   {
     
   
    play_sound();
 
    $('.count').html(data.unseen_notification);
   }

  }

 });

}

load_unseen_notification();

// load new notifications

$(document).on('click', '.dropdown-menu dropdown-menus', function(){

 $('.count').html(' ');

 load_unseen_notification('yes');

});

setInterval(function(){

 load_unseen_notification();;

}, 5000);

});

</script>