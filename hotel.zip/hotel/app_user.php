<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->

<?php
@session_start();
if(!isset($_SESSION['uid'])){
    echo "<script>window.location='index.php'</script>";
    session_destroy();
}
include_once('classes/DashboardClass.php');
include_once('classes/Utility.php');
include_once('language/lang_en.php');
require_once('header_link.php');
include_once('pagination.php');
$page_limit=10;
if (isset($_GET['page'])) {
  $page=$_GET['page'];
}
else {
  $page=1;
}
if ($page=='' || $page==1) {
  $page1=0;
}
else{
  $page1=($page*$page_limit)-$page_limit;
}
if(isset($_GET['serach']) && $_GET['serach'] != ""){
	$row=DashboardClass::getalluser_serach($_GET['serach'],$page1,$page_limit);
	$getTotaluser=DashboardClass::getTotaluser_serach($_GET['serach']);  
}else{
	$row=DashboardClass::getalluser($page1,$page_limit);
	$getTotaluser=DashboardClass::getTotaluser();  	
} 
?> 
<body>
<?php require_once('side_menu.php'); ?> 
  
<?php

if(isset($_GET['app_user_id']))
{
	$app_user_id =$_GET['app_user_id'];
	$sql = mysqli_query($conn,"DELETE FROM `app_user` WHERE `id`=".$app_user_id."");
	echo "<script>window.location.href='app_user.php';</script>";
}
?>
    <div id="right-panel" class="right-panel">
	<?php require_once('header.php'); ?> 
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo $language['app_user']; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active"><?php echo $language['app_user']; ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
         <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                        	 <div class="col-sm-8">
				                <div class=" float-left">
				                   	<strong class="card-title"><?php echo $language['data_table']; ?></strong> 
				                </div>
				            </div>
				            <div class="col-sm-4">
				                <div class="p">
				                	<div class="row">
				                		<form method="get">
				                		<div class="col-md-8">
				                			<?php if(isset($_GET['serach'])){
				                			?>
				                			<input placeholder="moblie number" required="" value="<?php echo $_GET['serach']?>" type="text" name="serach" class="form-control">
				                			<?php
				                			} else { ?>
				                    		<input placeholder="Moblie number" required="" type="text" name="serach" class="form-control">
				                    		<?php } ?>
				                    	</div>
				                    	<div class="col-md-2">
				                    		<?php if(isset($_GET['serach'])){
				                    		?>
				                    		<a href="app_user.php" class="btn btn-primary btn-md"><?php echo $language['reset'];?></a>
				                    		<?php
				                    		} else { ?>
				                    		<button class="btn btn-primary btn-md" type="submit"><?php echo $language['search_btn'];?></button>
				                    		<?php } ?>
				                    	</div>
				                    	</form>
				                	</div>
				                </div>
				            </div>
                        </div>
                        <div class="card-body">
                        <?php if ($row)
						{ ?>
		                <table  class="table table-striped table-bordered">
		                    <thead>
								<tr>
									<th><?php echo $language['id']; ?></th>
									<th><?php echo $language['mobile_number']; ?></th>
									<th><?php echo $language['created_at']; ?></th>
									<th><?php echo $language['action']; ?></th>	
								</tr>
		                    </thead>
							
		                    <tbody>
							<?php
								$t = 1;
								for($i=0;$i<count($row);$i++) 
								{ ?>
										<tr>	
											<td><?php echo $t;?></td>
											<td><?php echo $row[$i]->mob_number; ?></td>	
											<td><?php echo $row[$i]->create_at; ?></td>
											<td>
												<?php if($GLOBALS['button'] == 'YES') { ?>
													<a class="btn btn-md btn-danger " href="" onClick="return confirm('This function is currently disable as it is only a demo website, in your admin it will work perfect')"><?php echo $language['delete_btn']; ?></a>
													
												<?php } else { ?>

													<a  href="app_user.php?app_user_id=<?php echo $row[$i]->id; ?>" onclick="return confirm('Are you sure you want to delete?')"><button   type="button" class="btn btn-md btn-danger "><?php echo $language['delete_btn']; ?></button></a>
												<?php } ?>
											</td>
												
										</tr>
								<?php $t++; 
								}
								?>	
					     	 </tbody>
		                 	</table>
		                 	<div class="">
							<?php
			                if(isset($_GET['page']))
			                {
			                    $select=$_GET['page'];
			                }
			                else
			                {
			                    $select=1;
			                }
			                if(isset($_GET['serach'])){
			                   $url="app_user.php?serach=".$_GET['serach']."&"; 
			                }else{
			                  $url="app_user.php?";  
			                }
			               
			                echo pagination($getTotaluser,10,$select,$url);
			            	?>
							</div>
							<?php 
							}else
							{
								echo "Data not Found";
							}
							?>
            			</div>
        			</div>
    			</div>
			</div>
		</div><!-- .animated -->
	</div><!-- .content -->
</div><!-- /#right-panel -->
<?php require_once('footer_link.php'); ?> 
