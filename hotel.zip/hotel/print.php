<?php
session_start();
 require_once('connection.php'); 
////
if(isset($_REQUEST['id']))
{
	$id = $_REQUEST['id'];
	$total_amt_sum=0;
?>
<div>
	<div class="container">
			<?php		
			$sql_cur = "SELECT * FROM `food_user`";
			$cur = $conn->query($sql_cur);
			$cursim = $cur->fetch_assoc();
			
			$set_order_sql = "SELECT * FROM `set_order_detail` where id='".$id."'";
			$resultt = $conn->query($set_order_sql);
			$set_order_row = $resultt->fetch_assoc();
			
			$string1 = $cursim['currency'];
			$val = explode("-",$string1);
			if($cursim['currency'] != "")
				{
					 $cur = $val[1]; 
				}
				else
				{
					 $cur = "$";
				}
				
			?>	
			<div class="modal-header">
				<h5 class="modal-title">Order No:&nbsp;<?php echo $set_order_row['id']; ?>&nbsp;-&nbsp;</h5>
				<h5  class="modal-title" id="myamt"></h5><h5  class="modal-title">
				<?php echo $cur; ?>
				</h5>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
<style>
.bill_tbl
{
	border-top:0px!important;
	padding:0.35rem!important;
}
</style>
		<?php
			$sql = "SELECT * FROM `app_user` where id='".$set_order_row['user_id']."'";
			$result = $conn->query($sql);
			while($user = $result->fetch_assoc()) 
				{ ?>
			<h5 style="border-bottom:1px rgba(0,0,0,.2) solid;padding:6px 0px;">Person Detail</h5> 
			
					<div><b><?php echo  $user["name"]; ?></b></div>
					<div><?php echo  $user["mob_number"]; ?></div> 
					<div><?php date_default_timezone_set('Asia/Kolkata'); echo $date = date('y-m-d h:i:s'); ?></div>
					<div style="padding-right:120px;"><?php echo  $user["address"]; ?></div> </br>
					<div>Payment Type : <?php echo  $user["payment_type"]; ?></div>
					<div>Notes : <?php echo  $user["notes"]; ?></div></br>
				</div>
		<?php 	} ?>
		
		
		<h5>Order Detail</h5> 				
			<table class="table">
				<tbody>
					<tr>
						<th>Item Name</th>
						<th>Item Qty</th>
						<th>Price</th>
						<th>Total Price</th>
					</tr>
					
					<?php 
						$sqll = "SELECT * FROM `fooddelivery_food_desc` where set_order_id = '".$id."'";
						$result = $conn->query($sqll);
							foreach($result as $item) 
							{ 
					?>		
						<tr>
							<?php 
							$sql = "SELECT * FROM `food_menu` where id = '".$item["item_id"]."'";
							$result_ingredients = $conn->query($sql);
							foreach($result_ingredients as $menu_items) 
							{ ?>
								<td>
									<b><?php echo $menu_items['menu_name']; ?></b></br>
									<?php   }
									
										$sqll_inte_inner = "SELECT * FROM `food_ingredients` where id IN(".$item["ingredients_id"].")";
										$result_inte_inner = $conn->query($sqll_inte_inner);
										foreach($result_inte_inner as $item_inte_inner) 
										{
											echo $item_inte_inner['item_name']."</br>";
										} ?> 
								</td>
							
								<td><b><?php echo $item["item_qty"] ?></b></td>
								<td>
									<b><?php echo $menu_items['price'].$cur; ?> </b></br>
									<?php
									$sqll_inte_inner = "SELECT * FROM `food_ingredients` where id IN(".$item["ingredients_id"].")";
										$result_inte_inner = $conn->query($sqll_inte_inner);
										foreach($result_inte_inner as $item_inte_inner) 
										{	
											if($item_inte_inner['price'] == 0)
											{
												echo "---</br>";
											}
											else
											{
												echo $item_inte_inner['price'] . $cur."</br>";
											}
										} ?> 
								</td>
								<td><?php echo $item["item_amt"] . $cur ?></td>
						</tr>
						
							<?php } ?>
					
						<script>
						jQuery("#myamt").html(<?php echo $set_order_row['total_price']; ?>);
					</script>
				</tbody>
			</table>
		
	</div>
</div>

<?php 
}
?>