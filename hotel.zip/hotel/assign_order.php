<?php
require_once('connection.php');
include_once('language/lang_en.php');
$id = $_POST['id'];
$boy_list = mysqli_query($conn,"select * from food_delivery_boy where attendance='yes'");
?>
<div class="form-group">
	<label><?php echo $language['order_id']; ?> <span style="color: red;">*</span> :</label>
	<input class="form-control" type="text" value="<?php echo $id; ?>"  name="order_id" readonly="" style="cursor: no-drop;"/>
</div>
<div class="form-group">
	<label><?php echo $language['select_delivery_boy']; ?> <span style="color: red;">*</span> :</label>
	<select class="form-control" id="message" name="boy_id" required="">
	<option value=""><?php echo $language['select_name']; ?></option>
		<?php
		while ($list = mysqli_fetch_array($boy_list))
		{
		?>
			<option value="<?php echo $list['id']; ?>"><?php echo $list['name']; ?></option>
		<?php
		}
		?>
	</select>
</div>