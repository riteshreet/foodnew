<?php
$preparing_msg = 'your order has beed accepted by restaurant, they are start preparing order';
$delivered_msg = 'Your order  is picked up, thank you for business with us';
$reject_msg = "your order has been rejected by restaurant, try another restaurant";
$complete_msg = "Your order is delivered";
$pickorder_msg = "Your order  is picked and soon will be deliverd";
$assginorder_msg = "Your Order has been assigned to delivery boy, you will get knocked at your door step";
$deliveryboy_msg = "You have assigned new order delivery by restaurant, pickup as soon as possible.";
?>