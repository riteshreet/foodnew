<?php
require_once('classes/Utility.php');


   $update_query = "UPDATE set_order_detail SET notify=2  where notify=1";
   mysqli_query($conn, $update_query);

?>