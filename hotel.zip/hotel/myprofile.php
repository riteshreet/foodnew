<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->

<?php 
@session_start();
include_once('language/lang_en.php');
if(!isset($_SESSION['uid'])){
    echo "<script>window.location='index.php'</script>";
    session_destroy();
}
require_once('classes/Utility.php');
require_once('header_link.php'); ?> 
<body>

<?php require_once('side_menu.php'); ?> 
       
    <!-- Left Panel -->

    <!-- Right Panel -->

<?php
$success=0;
if(isset($_POST["add_profile"]))
{
	$name = $_POST['name'];
	$password = $_POST['password'];
	$email = $_POST['email'];	
	$id= $_POST['id'];		
	
	$success = mysqli_query($conn,"UPDATE `food_user` SET `email`='".$email."',`password`='".$password."',`user_name`='".$name."' WHERE userid='".$id."'");
		
		 
	}	
?>

 <div id="right-panel" class="right-panel">
	<?php require_once('header.php'); ?> 
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo $language['profile']; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active"><?php echo $language['profile']; ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

	
	<?php
		if($success==true)
		{ ?>
	
	<div class="container">
		<div style="margin:28px 0px -48px 0px;">
			<div class="bs-example">
				<div class="alert alert-success">
					<a href="#" class="close" data-dismiss="alert">&times;</a>
					<strong><?php echo $language['successfull']; ?> </strong><?php echo $language['profile_update_msg']; ?>
				</div>
			</div>
		</div>
	</div>
		<?php }
		else{
			}
	?>
	
 <div class="content mt-3">
    <div class="animated">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title"><?php echo $language['profile']; ?>e</h5>
					</div>
					<div class="modal-body">
						<form action="" method="post" enctype="multipart/form-data">
                        
						 <?php
							$sql = "SELECT * FROM `food_user`";
							$result = $conn->query($sql);
							if ($result->num_rows > 0)
							{
								while($row = $result->fetch_assoc()) 
								{ ?>
								<div class="form-group">
									<label><?php echo $language['name']; ?></label>
									<input type="text" class="form-control" name="name" value="<?php echo  $row["user_name"]; ?>" >
								</div>
								<div class="form-group">
									<label><?php echo $language['email_id']; ?></label>
									<input type="text" class="form-control" name="email" value="<?php echo  $row["email"]; ?>" >
								</div>
								<div class="form-group">
									<label><?php echo $language['password']; ?></label>
									<input type="text" class="form-control" name="password" value="<?php echo  $row["password"]; ?>" >
								</div>
								
								<input type="hidden" class="form-control" name="id" value="<?php echo $row['userid']; ?>">
								<?php if($GLOBALS['button'] == 'YES') { ?>
									<a class="btn btn-md btn-success " href="" onClick="return confirm('This function is currently disable as it is only a demo website, in your admin it will work perfect')"><?php echo $language['edit_btn']; ?></a>
													
												
								<?php } else { ?>
								<button name="add_profile" type="submit" class="btn btn-md btn-success "><?php echo $language['edit_btn']; ?></button>
								<?php } ?>
					
							<?php }
								}
							?>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

  <?php require_once('footer_link.php'); ?> 