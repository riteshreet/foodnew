<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->

<?php
@session_start();
if(!isset($_SESSION['uid'])){
   echo "<script>window.location='index.php'</script>";
    session_destroy();
}
include_once('classes/CategoryClass.php');
include_once('classes/MenuitemClass.php');
include_once('classes/Utility.php');
include_once('language/lang_en.php');
require_once('header_link.php'); 
include_once('pagination.php');
$page_limit=10;
if (isset($_GET['page'])) {
  $page=$_GET['page'];
}
else {
  $page=1;
}
if ($page=='' || $page==1) {
  $page1=0;
}
else{
  $page1=($page*$page_limit)-$page_limit;
}
if(isset($_GET['serach']) && $_GET['serach'] != ""){
	$res=MenuitemClass::getallitem_serach($_GET['serach'],$page1,$page_limit);
	$getTotalitem=MenuitemClass::getTotalitem_serach($_GET['serach']);  
}else{
	$res=MenuitemClass::getallitem($page1,$page_limit);
	$getTotalitem=MenuitemClass::getTotalitem();  	
}
?> 
<body>
<?php require_once('side_menu.php');
?>

<div id="right-panel" class="right-panel">
	<?php require_once('header.php'); ?> 
	 	<div class="breadcrumbs">
	        <div class="col-sm-4">
	            <div class="page-header float-left">
	                <div class="page-title">
	                    <h1><?php echo $language['menu_item']; ?></h1>
	                </div>
	            </div>
	        </div>
	        <div class="col-sm-8">
	            <div class="page-header float-right">
	                <div class="page-title">
	                    <ol class="breadcrumb text-right">
	                        <li class="active"><?php echo $language['menu_item']; ?></li>
	                    </ol>
	                </div>
	            </div>
	        </div>
	    </div>
<?php
if(isset($_POST["add_menu_item"]))
{
	$objItem=new MenuitemClass();
    $objItem->category=$_POST['item_category'];
    $objItem->description=$_POST['item_description'];
    $objItem->menu_name=$_POST['item_name'];
    $objItem->price=$_POST['item_price'];

    $img_file=$_FILES['file']['name'];
    $temp_img_file = explode(".", $_FILES["file"]["name"]);
    $newfilename = "Menuitem_". round(microtime(true)) . '.' . end($temp_img_file);
    if(end($temp_img_file) == 'png' || end($temp_img_file) == 'jpeg' || end($temp_img_file) == 'JPG' || end($temp_img_file) == 'jpg'){
    $objItem->menu_image=$newfilename;
    $tpath1='images/menu_item_icon/'.$newfilename;
    $objMessage=MenuitemClass::insertNewMenu($objItem);                   
    if ($objMessage->status==1) { 
       move_uploaded_file($_FILES["file"]["tmp_name"], "images/menu_item_icon/" . $newfilename);
      echo "<script>window.location.href='menu_item.php';</script>";
    }
    else{
        echo "<script>window.location.href='menu_item.php';</script>";
    }
    }else{
      ?>
        <script>alert("plz select png,jpg,jpeg image");</script>
        <?php
        echo "<script>window.location.href='menu_category.php';</script>";
    }
}

if(isset($_POST["editmenu"]))
{

	$obj=new MenuitemClass();
    $id = $_POST['id'];
    $objItem=MenuitemClass::getmenuitemByID($id);
    $obj->menu_name=($objItem->menu_name==$_POST['item_name']) ? $objItem->menu_name : $_POST['item_name'];
    $obj->category=$_POST['item_category'];
    $obj->description=$_POST['item_description'];
    $obj->price=$_POST['item_price'];
    $image=$_FILES['file']['name'];
    $Oldimg = $_POST['image'];
    if (strlen($image)!=0) {
      $temp_img_file = explode(".", $_FILES["file"]["name"]);
      $newfilename = "Menuitem_".round(microtime(true)) . '.' . end($temp_img_file);
      if(end($temp_img_file) == 'png' || end($temp_img_file) == 'jpeg' || end($temp_img_file) == 'JPG' || end($temp_img_file) == 'jpg'){
      $obj->menu_image=$newfilename;
      $tpath1='images/menu_item_icon/'.$newfilename;
      $objMessage=MenuitemClass::updateMenu($obj,$id);
      if($objMessage->status==1){
        $file_path="images/menu_item_icon/$Oldimg";
         unlink($file_path);
         move_uploaded_file($_FILES["file"]["tmp_name"], "images/menu_item_icon/" . $newfilename);
        echo "<script>window.location.href='menu_item.php';</script>";
      }
      else{
        echo "<script>window.location.href='menu_item.php';</script>";
      }
      }else{
      ?>
        <script>alert("plz select png,jpg,jpeg image");</script>
        <?php
         echo "<script>window.location.href='menu_category.php';</script>";
        }
    }
    else{
      $obj->menu_image=$Oldimg;
      $objMessage=MenuitemClass::updateMenu($obj,$id);
      if($objMessage->status==1){
          echo "<script>window.location.href='menu_item.php';</script>";
      }
      else{
       echo "<script>window.location.href='menu_item.php';</script>";
      }
    }
}

if(isset($_GET['app_item_did']))
{
		$app_item_did =$_GET['app_item_did'];
		
		$sql_menu = mysqli_query($conn,"SELECT * FROM `food_menu` where `id` = $app_item_did");
		
		$row_menu =mysqli_fetch_array($sql_menu);
		$menu_image = $row_menu['menu_image'];
		unlink("images/menu_item_icon/$menu_image");
		
		$sql = mysqli_query($conn,"DELETE FROM `food_menu` WHERE `id`=".$app_item_did."");
		
		
		$sql = mysqli_query($conn,"DELETE FROM `food_ingredients` WHERE `menu_id`=".$app_item_did."");
		
		echo "<script>window.location.href='menu_item.php';</script>";
}
?>
<div class="content mt-3">
	<div class="animated">
	<div class="breadcrumbs">  
        <div class="page-header float-left">
            <div class="page-title">
                <h1><button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#myModal"><?php echo $language['add_menu_item']; ?></button></h1>
            </div>
        </div>
    </div>
	<div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
				<div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                             <div class="col-sm-8">
				                <div class=" float-left">
				                   	<strong class="card-title"><?php echo $language['data_table']; ?></strong> 
				                </div>
				            </div>
				            <div class="col-sm-4">
				                <div class="p">
				                	<div class="row">
				                		<form method="get">
				                		<div class="col-md-8">
				                    		<?php if(isset($_GET['serach'])){
				                			?>
				                			<input required="" value="<?php echo $_GET['serach']?>" type="text" name="serach" class="form-control">
				                			<?php
				                			} else { ?>
				                    		<input required="" type="text" name="serach" class="form-control">
				                    		<?php } ?>
				                    	</div>
				                    	<div class="col-md-2">
				                    		<?php if(isset($_GET['serach'])){
				                    		?>
				                    		<a href="menu_item.php" class="btn btn-primary btn-md"><?php echo $language['reset'];?></a>
				                    		<?php
				                    		} else { ?>
				                    		<button class="btn btn-primary btn-md" type="submit"><?php echo $language['search_btn'];?></button>
				                    		<?php } ?>
				                    	</div>
				                    	</form>
				                	</div>
				                </div>
				            </div>
	       
                        </div>
						<div class="card-body">
							<?php 
							if ($res)
								{
							?>
							<table  class="table table-striped table-bordered">
								<thead>
									<tr>
										<th><?php echo $language['id']; ?></th>
										<th><?php echo $language['item_name']; ?></th>
										<th><?php echo $language['category']; ?></th>
										<th><?php echo $language['description']; ?></th>
										<th><?php echo $language['price']; ?></th>
										<th><?php echo $language['image']; ?></th>
										<th><?php echo $language['action']; ?></th>
									</tr>
								</thead>
								<tbody>
									<?php
									$t=1;
										for($i=0;$i<count($res);$i++)
										{ ?>
											<tr>
												<td><?php echo $t;?></td>
												<td><?php echo $res[$i]->menu_name; ?></td>
												<?php $category = CategoryClass::getcategory($res[$i]->category)?>	
												<td><?php echo  $category->cat_name; ?></td>
												<td width="350px;"><?php echo $res[$i]->description;?></td>
												<td><?php echo  $res[$i]->price; ?></td>
												<td><img  class="img-fluid" src="images/menu_item_icon/<?php echo  $res[$i]->menu_image; ?>" width="80px"></td>
												<td>
													<?php if($GLOBALS['button'] == 'YES') { ?>
													<a class="btn btn-md btn-danger " href="" onClick="return confirm('This function is currently disable as it is only a demo website, in your admin it will work perfect')"><?php echo $language['delete_btn']; ?></a>
													
													<a href="" onClick="return confirm('This function is currently disable as it is only a demo website, in your admin it will work perfect')" class="btn btn-md btn-info"><?php echo $language['edit_btn']; ?></a>
													<?php } else { ?>
													<a class="btn btn-md btn-danger " href="menu_item.php?app_item_did=<?php echo $res[$i]->id; ?>" onclick="return confirm('Are you sure you want to delete?')"><?php echo $language['delete_btn']; ?></a>
													
													<a href="" id="mySelect" onclick="getmenu(<?php echo  $res[$i]->id; ?>)"  class="btn btn-md btn-info" data-toggle="modal" data-target="#menuitem_edit_Modal"><?php echo $language['edit_btn']; ?></a>
													<?php } ?>
												</td>
											</tr>
								  		<?php $t++ ;
								  		}
										?>
								</tbody>
							</table>
							<div class="">
								<?php
				                if(isset($_GET['page']))
				                {
				                    $select=$_GET['page'];
				                }
				                else
				                {
				                    $select=1;
				                }
				                if(isset($_GET['serach'])){
				                   $url="menu_item.php?serach=".$_GET['serach']."&"; 
				                }else{
				                  $url="menu_item.php?";  
				                }
				               
				                echo pagination($getTotalitem,10,$select,$url);
				            	?>
							</div>
						<?php } ?>
                        </div>
                    </div>
                </div>
			</div>
        </div>
    </div>
</div>
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title"><?php echo $language['add_menu_item']; ?></h5>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<form name="menu_form_item" action="" method="post" enctype="multipart/form-data">
                        <div class="form-group">
							<label><?php echo $language['select_category']; ?></label></br>
							<select name="item_category" class="form-control" required >
								<option disabled selected value><?php echo $language['select_category']; ?></option>
								 <?php
								 $arr1 = CategoryClass::getallcategory();
						          for ($i=0; $i < count($arr1); $i++) {
						            echo "<option value='".$arr1[$i]->id."'>".$arr1[$i]->cat_name ."</option>";
						           
						          }
						          ?>
							</select>
                   	
						</div>
                        <div class="form-group">
                            <label><?php echo $language['item_name']; ?></label>
                            <input type="text" class="form-control" placeholder="<?php echo $language['item_name']; ?>"  name="item_name" required >
                        </div>
						<div class="form-group">
                            <label><?php echo $language['description']; ?></label>
							<textarea class="form-control" placeholder="<?php echo $language['description']; ?>" name="item_description" required></textarea>
                        </div>
						 <div class="form-group">
                            <label><?php echo $language['price']; ?></label>
                            <input type="text" class="form-control" placeholder="<?php echo $language['price']; ?>" name="item_price" required>
                        </div>
						 <div class="form-group">
                            <label><?php echo $language['select_image']; ?></label>
                            <input type="file" class="form-control" name="file" required  accept="image/png, image/jpeg, image/gif">
                        </div>
                       
                        <div class="col-md-12">
							<div class="col-md-6">
								<input type="submit" name="add_menu_item"  class="btn btn-primary btn-md form-control" value="<?php echo $language['add_btn']?>">
							</div>
							<div class="col-md-6">
								<input type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="<?php echo $language['close_btn']?>">
							</div>
						</div>
						 
					</form>
				</div>
		
			</div>
		</div>
	</div>
  </div>
  <div class="modal fade" id="menuitem_edit_Modal" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<form action="" method="post" enctype="multipart/form-data">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title"><?php echo $language['edit_menu_category']; ?></h5>
								<button type="button" class="close" data-dismiss="modal">&times;</button>
							</div>
							<div class="modal-body" id="cat_edit_form">
								 <div id="showgallery">	
							</div>

						<div class="col-md-12">
							<div class="col-md-6">
								<input type="submit" name="editmenu"  class="btn btn-primary btn-md form-control" value="<?php echo $language['edit_btn']; ?>">
							</div>
							<div class="col-md-6">
								<input type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="<?php echo $language['close_btn']?>">
							</div>
						</div>
					</div>
					</form>

				</div>
			</div>
		</div>
</div>
<script>
        function getmenu(id) {
            
            var url='ajax/edit_menu_item.php?id='+id;
            
            $.ajax({
                url: url,
                type: 'GET',
                success: function (data) {
                   if (data)
                {
                    $('#showgallery').replaceWith($('#showgallery').html(data));
                }
                else
                {
                    alert('error');
                }
                                        
                },
                error: function(e) {
                    alert('Error: '+e);
                }
            });
        }
</script>
<?php require_once('footer_link.php'); ?> 