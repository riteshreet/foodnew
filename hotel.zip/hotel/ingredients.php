<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->

<?php 
@session_start();
if(!isset($_SESSION['uid'])){
    echo "<script>window.location='index.php'</script>";
    session_destroy();
}
include_once('classes/CategoryClass.php');
include_once('classes/MenuitemClass.php');
include_once('classes/Utility.php');
include_once('classes/IngredientsClass.php');
include_once('language/lang_en.php');
require_once('header_link.php'); 
include_once('pagination.php');
$page_limit=10;
if (isset($_GET['page'])) {
  $page=$_GET['page'];
}
else {
  $page=1;
}
if ($page=='' || $page==1) {
  $page1=0;
}
else{
  $page1=($page*$page_limit)-$page_limit;
}
if(isset($_GET['ingredients_cat']) && $_GET['ingredients_cat'] != "" && isset($_GET['ingredients_menu']) && $_GET['ingredients_menu']  != ""){
	$row_search=IngredientsClass::getallingr_serach($_GET['ingredients_cat'],$_GET['ingredients_menu'],$page1,$page_limit);
	$getTotalingr=IngredientsClass::getTotalingr_serach($_GET['ingredients_cat'],$_GET['ingredients_menu']);  
}else{
	$row_search=IngredientsClass::getallingr($page1,$page_limit);
	$getTotalingr=IngredientsClass::getTotalingr();  	
}
?> 
<body>

<?php require_once('side_menu.php'); ?> 
    

<div id="right-panel" class="right-panel">
	<?php require_once('header.php'); ?> 
        <!-- Header-->
        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo $language['ingredients_item']; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active"><?php echo $language['ingredients_item']; ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <?php
if(isset($_POST["add_ingredients"]))
{
	$objIngt=new IngredientsClass();
    $objIngt->category = $_POST['ingredients_cat'];
	$objIngt->menu_id = $_POST['ingredients_menu'];
	$objIngt->type = $_POST['ingredients_type'];
	$objIngt->price = $_POST['ingredients_price'];
	$objIngt->item_name = $_POST['ingredients_item'];

    $objMessage=IngredientsClass::insertNewinteg($objIngt);                   
    if ($objMessage->status==1) { 
     echo "<script>window.location.href='ingredients.php';</script>";
    }
    else{
         echo "<script>window.location.href='ingredients.php';</script>";
    }

}

if(isset($_POST["editingredients"]))
{
	 $obj=new IngredientsClass();
     $id = $_POST['id'];
     $objIngre=IngredientsClass::getingreById($id);
     $obj->item_name=($objIngre->item_name==$_POST['ingredients_item']) ? $objIngre->item_name : $_POST['ingredients_item'];
   	$obj->category = $_POST['ingredients_cat'];
	$obj->menu_id = $_POST['ingredients_menu'];
	$obj->type = $_POST['ingredients_type'];
	$obj->price = $_POST['ingredients_price'];
      $objMessage=IngredientsClass::updateingre($obj,$id);
      if($objMessage->status==1){
        echo "<script>window.location.href='ingredients.php';</script>";
      }
      else{
        echo "<script>window.location.href='ingredients.php';</script>";
      }
 }
if(isset($_GET['app_ingred_did']))
	{
		$app_ingred_did =$_GET['app_ingred_did'];
		$sql = mysqli_query($conn,"DELETE FROM `food_ingredients` WHERE `id`=".$app_ingred_did."");
		echo "<script>window.location.href='ingredients.php';</script>";
		
	}
?>
<div class="content mt-3">
	<div class="animated">
<!-- Trigger the modal with a button -->	
	<div class="breadcrumbs">  
        <div class="page-header float-left">
            <div class="page-title">
                <h1><button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#myModal"><?php echo $language['add_menu_ingredients']; ?></button></h1>
            </div>
        </div>
    </div>	
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title"><?php echo $language['add_menu_ingredients']; ?></h5>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<form name="menu_form_item" action="" method="post" enctype="multipart/form-data">
						<label><?php echo $language['select_menu_category']; ?></label></br>
						<div class="form-group">
                        	<select  name="ingredients_cat" id="mySelect" onchange="myFunction()" class="form-control" required>
							<option disabled selected value><?php echo $language['select_menu_category']; ?> </option>
							 <?php
							 $arr1 = CategoryClass::getallcategory();
					          for ($i=0; $i < count($arr1); $i++) {
					            echo "<option value='".$arr1[$i]->id."'>".$arr1[$i]->cat_name ."</option>";
					          }
					          ?>	
							</select>
							
						</div>
						<label><?php echo $language['select_menu_item']; ?></label></br>
						<div class="form-group">
							<select name="ingredients_menu" id="submit_sub_category" class="form-control" required >
								<option disabled selected value> <?php echo $language['select_menu_item']; ?></option>
							</select>
						</div>
	
						<label><?php echo $language['item_name']; ?></label>
						<div class="form-group">
                           <input type="text" class="form-control" placeholder="<?php echo $language['item_name']; ?>"  name="ingredients_item" required>
						</div>
						
						<label><?php echo $language['type']; ?></label>
						<div class="form-group">
							<div class="radio">
							<label><input value="1" type="radio" onclick="javascript:yesnoCheck();" name="ingredients_type" id="yesCheck" required >&nbsp;<?php echo $language['paid']?></label>
							&nbsp;&nbsp;&nbsp;&nbsp;
							<label><input value="0" type="radio" onclick="javascript:yesnoCheck();" name="ingredients_type" id="yesCheck" required >&nbsp;<?php echo $language['free']; ?></label>
							</div>
						</div>
	
						<div class="form-group">
							<div id="ifYes" style="display:none;">
							<label><?php echo $language['item_price']; ?></label>
								<input type="text" id="myText" value="0" class="form-control" placeholder="<?php echo $language['item_price']; ?>"  name="ingredients_price" required  >
							</div>
						</div>
						
						 <div class="col-md-12">
							<div class="col-md-6">
								<input type="submit" name="add_ingredients"  class="btn btn-primary btn-md form-control" value="<?php echo $language['add_btn']; ?>">
							</div>
							<div class="col-md-6">
								<input type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="<?php echo $language['close_btn']; ?>">
							</div>
						</div>
					</form>
				</div>
				</div>
			</div>
		</div>
</div>
<div class="modal fade" id="ingre_edit_Modal" role="dialog">
    <div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-content">
				
			<form action="" method="post" enctype="multipart/form-data">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title"><?php echo $language['edit_menu_ingredients']; ?></h5>
								<button type="button" class="close" data-dismiss="modal">&times;</button>
							</div>
							<div class="modal-body" id="cat_edit_form">
								 <div id="showgallery">	
							</div>

						<div class="col-md-12">
							<div class="col-md-6">
								<input type="submit" name="editingredients"  class="btn btn-primary btn-md form-control" value="<?php echo $language['edit_btn']; ?>">
							</div>
							<div class="col-md-6">
								<input type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="<?php echo $language['close_btn']; ?>">
							</div>
						</div>
					</div>
					</form>
				</div>
				</div>
			</div>
		</div>
</div>
	<div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
            		<div class="col-md-12">
	                    <div class="card">
	                        <div class="card-header">
	                           	 <div class="col-sm-4">
						                <div class=" float-left">
						                   	<strong class="card-title"><?php echo $language['data_table']; ?></strong> 
						                </div>
						            </div>
						            <div class="col-sm-8">
						                <div class="p">
						                	<div class="row">
						                		<form method="get">
									                <div class="col-md-5">
									                	<select  name="ingredients_cat" id="mySelect_srt" onchange="myFunction_srt()" class="form-control" required>
															<option disabled selected value> <?php echo $language['select_category']; ?></option>
														
															 <?php
															 $arr1 = CategoryClass::getallcategory();
													          for ($i=0; $i < count($arr1); $i++) {
													            echo "<option value='".$arr1[$i]->id."'>".$arr1[$i]->cat_name ."</option>";
													          }
													          ?>
														</select>
									                </div>
									                <div class="col-5">
									                	<select name="ingredients_menu" id="submit_sub_category_sort" class="form-control" required >
															<option disabled selected value> <?php echo $language['select_menu_item']; ?> </option>
														</select>
									                </div>
									                <?php if(isset($_GET['ingredients_menu'])) { ?>
									                <a href="ingredients.php" class="btn btn-primary btn-md"><?php echo $language['reset']; ?></a>
									            	<?php } else { ?>
									            	<button type="submit" class="btn btn-primary btn-md"><?php echo $language['sort']; ?></button>
									            	<?php } ?>
									            </form>
						                	</div>
						                </div>
						            </div>
	                        </div>
	                        <div class="card-body">
	                        	<?php
	                        	if ($row_search)
								{
	                        	?>
								<table  class="table table-striped table-bordered">
									<thead>
									 <tr>
									 	<th><?php echo $language['id']; ?></th>
									 	<th><?php echo $language['category_name']; ?></th>
										<th><?php echo $language['item_name']; ?></th>
										<th><?php echo $language['ingredients_name']; ?></th>
										<th><?php echo $language['type']; ?></th>
										<th><?php echo $language['price']; ?></th>
										<th><?php echo $language['delete_btn']; ?></th>
									</tr>
									</thead>
									<tbody>
										<?php
										
										$t=1;
										for($i=0;$i<count($row_search);$i++) 
										{ ?>
												<tr>
												<?php								 
												$arr = CategoryClass::getcategory($row_search[$i]->category);
												$arr2=MenuitemClass::getmenuitemByID($row_search[$i]->menu_id);
												?>
												<td><?php echo $t;?></td>
												<td><?php echo  $arr->cat_name; ?></td>
												<td><?php echo  $arr2->menu_name; ?></td>
												<td><?php echo  $row_search[$i]->item_name; ?></td>	
												<?php
													if($row_search[$i]->price==0)
													{ ?>
														<td><?php echo $language['free']; ?></td>
													<?php }
													else
													{ ?>
														<td><?php echo $language['paid']; ?></td>
													<?php }
												?>
												<td><?php echo  $row_search[$i]->price; ?></td>
												
												<td>
												<?php if($GLOBALS['button'] == 'YES') { ?>
												<a class="btn btn-md btn-danger " href="" onClick="return confirm('This function is currently disable as it is only a demo website, in your admin it will work perfect')"><?php echo $language['delete_btn']; ?></a>
													
												<a href="" onClick="return confirm('This function is currently disable as it is only a demo website, in your admin it will work perfect')" class="btn btn-md btn-info"><?php echo $language['edit_btn']; ?></a>
												<?php } else { ?>
												<a class="btn btn-md btn-danger" href="ingredients.php?app_ingred_did=<?php echo $row_search[$i]->id; ?>" onclick="return confirm('Are you sure you want to delete?')"><?php echo $language['delete_btn']; ?></a>
												
												<a id="mySelect" onclick="editinteg(<?php echo  $row_search[$i]->id; ?>)"  class="btn btn-md btn-info" data-toggle="modal" data-target="#ingre_edit_Modal"><?php echo $language['edit_btn']; ?></a>
												<?php } ?>
												</td>
												
												
											   </tr>
										<?php $t++; }
									?>
									</tbody>
								</table>
								<div class="">
									<?php
					                if(isset($_GET['page']))
					                {
					                    $select=$_GET['page'];
					                }
					                else
					                {
					                    $select=1;
					                }
					                if(isset($_GET['serach'])){
					                   $url="ingredients.php?serach=".$_GET['ingredients_cat']."&ingredients_menu=".$_GET['ingredients_menu']."&"; 
					                }else{
					                  $url="ingredients.php?";  
					                }
					               
					                echo pagination($getTotalingr,10,$select,$url);
					            	?>
									</div>
									<?php 
									}else
									{
										echo "Data not Found";
									}
								?>
	                        </div>
	                    </div>
	                </div>
			</div>
        </div>
    </div>
</div>
<script>

function myFunction_srt() {
   
  var formData = document.getElementById("mySelect_srt").value;
  jQuery.ajax({
  type: 'post',
  url: 'ajax/getmenutem.php',
  data:'formData='+formData,

  success: function (response) {
 
  jQuery("#submit_sub_category_sort").html(response);
 }
 });
  
	
}
function myFunction() {
    var formData = document.getElementById("mySelect").value;
    
	
	
  jQuery.ajax({
  type: 'post',
  url: 'ajax/getmenutem.php',
  data:'formData='+formData,
	success: function (response) {
	
	jQuery("#submit_sub_category").html(response);
 }
 });
	
}


function Function() {
    var formData = document.getElementById("Select").value;
    
	
  jQuery.ajax({
  type: 'post',
  url: 'ajax/getmenutem.php',
  data:'formData='+formData,
	
	success: function (response) {
	
	jQuery("#submit_menu_name").html(response);
 }
 });
	
}



function yesnoCheck() {
    if (document.getElementById('yesCheck').checked) {
        document.getElementById('ifYes').style.display = 'block';
    }
    else 
	{
		document.getElementById('ifYes').style.display = 'none';
		document.getElementById("myText").value = "0";
	}	
}

function yesnoChecks() {
    if (document.getElementById('yesChecks').checked) {
        document.getElementById('ifYess').style.display = 'block';
    }
    else 
	{
		document.getElementById('ifYess').style.display = 'none';
		document.getElementById("myTextt").value = "0";
	}	
}


</script>		
	
    <script>
        function editinteg(id) {
            
            var url='ajax/edit_ingredients.php?id='+id;
            
            $.ajax({
                url: url,
                type: 'GET',
                success: function (data) {
                   if (data)
                {
                    $('#showgallery').replaceWith($('#showgallery').html(data));
                }
                else
                {
                    alert('error');
                }
                                        
                },
                error: function(e) {
                    alert('Error: '+e);
                }
            });
        }
    </script>

<?php require_once('footer_link.php'); ?> 
