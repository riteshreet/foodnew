
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->

<?php 
@session_start();
if(!isset($_SESSION['uid'])){
    echo "<script>window.location='index.php'</script>";
    session_destroy();
}
require_once('classes/Utility.php');
include_once('language/lang_en.php');
require_once('header_link.php'); ?> 
<body>

<?php require_once('side_menu.php'); ?> 
       
    <!-- Left Panel -->

    <!-- Right Panel -->

	<?php
	$success=0;
	if(isset($_POST["add_android_key"]))
	{
		$android_key_id = $_POST['android_key_id'];
		$android_key = $_POST['android_key'];
			
			$myandroid_key = $conn->real_escape_string($android_key);
				$sql = "UPDATE `food_notification` SET `android_key`='".$myandroid_key."' WHERE `id`=".$android_key_id."";
			 $success = $conn->query($sql);		
			 
		}	
?>

 <div id="right-panel" class="right-panel">
	<?php require_once('header.php'); ?> 
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo $language['android_notification']; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active"><?php echo $language['android_notification']; ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

	
	<?php
		if($success==true)
		{ ?>
	
	<div class="container">
		<div style="margin:28px 0px -48px 0px;">
			<div class="bs-example">
				<div class="alert alert-success">
					<a href="#" class="close" data-dismiss="alert">&times;</a>
					<strong><?php echo $language['successfull']; ?></strong> <?php echo $language['android_success_msg']; ?>
				</div>
			</div>
		</div>
	</div>
		<?php }
		else{
			}
	?>
	
 <div class="content mt-3">
    <div class="animated">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title"><?php echo $language['notification_title']; ?></h5>
					</div>
					<div class="modal-body">
						<form action="" method="post" enctype="multipart/form-data">
                        
						 <?php
							$sql = "SELECT * FROM `food_notification`";
							$result = $conn->query($sql);
							if ($result->num_rows > 0)
							{
								while($row = $result->fetch_assoc()) 
								{ ?>
					
								<div class="form-group">
									<label><?php echo $language['android_server_key']; ?></label>
									<input type="text" class="form-control" name="android_key" value="<?php echo  $row["android_key"]; ?>" >
								</div>
								<input type="hidden" class="form-control" name="android_key_id" value="<?php echo  $row["id"]; ?>" >
								<?php if($GLOBALS['button'] == 'YES') { ?>
									<a class="btn btn-md btn-success " href="" onClick="return confirm('This function is currently disable as it is only a demo website, in your admin it will work perfect')"><?php echo $language['save_changes_btn']; ?></a>
													
												
								<?php } else { ?>
									<button name="add_android_key" type="submit" class="btn btn-md btn-success "><?php echo $language['save_changes_btn']; ?></button>
					
								<?php }  }
								}
							?>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

  <?php require_once('footer_link.php'); ?> 
