<?php
ob_start();
	include_once('../classes/CategoryClass.php');
    $id=$_REQUEST['id'];
    $objCategory=CategoryClass::getcategory($id);
	
	include('../language/lang_en.php');   
    
          
?>
 <input type="hidden" name="id" id="id" value="<?php echo $objCategory->id;?>">
 <input type="hidden" name="image" id="image" value="<?php echo $objCategory->cat_icon;?>">
<div class="form-group">
    <label class="control-label"><?php echo $language['category_name']; ?></label>
    <input type="text" name="name" class="form-control" id="name" placeholder="<?php echo $language['category_name']; ?>" required="" value="<?php echo $objCategory->cat_name;?>">
</div>

                  

<div class="form-group">
    <label class="control-label"><?php echo $language['category_image']; ?></label>
    <input type="file" class="form-control" accept="image/png, image/jpeg, image/gif" name="file" id="file" />
</div>
<div class="form-group">
    <label class="control-label"><?php echo $language['selected_image']; ?></label>
    <img src="images/menu_cat_icon/<?php echo $objCategory->cat_icon?>" id="images" style="height: 150px;width: 150px">
   
</div>
</div>