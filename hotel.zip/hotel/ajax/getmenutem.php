 <?php include('../language/lang_en.php');  ?>
  <option value=''><?php echo $language['select_category']; ?></option>
<?php
require_once('../classes/Utility.php');
$cat=$_REQUEST['formData'];
 $query=mysqli_query($conn,"SELECT * FROM food_menu WHERE category='$cat' ORDER BY id DESC");

 
	include('../language/lang_en.php');  
   
      while ($obj=mysqli_fetch_object($query))
      {
      	?>
      	<option value="<?php echo $obj->id?>"><?php echo $obj->menu_name?></option>
      	<?php

      
      }
    
?>