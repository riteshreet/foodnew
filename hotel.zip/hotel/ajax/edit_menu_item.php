<?php
ob_start();
	include_once('../classes/MenuitemClass.php');
	include_once('../classes/CategoryClass.php');
    $id=$_REQUEST['id'];
    $objItem=MenuitemClass::getmenuitemByID($id);
    
	include('../language/lang_en.php');  
          
?>
 <input type="hidden" name="id" id="id" value="<?php echo $objItem->id;?>">
 <input type="hidden" name="image" id="image" value="<?php echo $objItem->menu_image;?>">
 <div class="form-group">
	<label><?php echo $language['select_category']; ?></label></br>
	<select name="item_category" class="form-control" required >
		 <?php
		  $arr=CategoryClass::getallcategory();
          for ($i=0; $i < count($arr); $i++) {
            if ($arr[$i]->id == $objItem->category) {
              echo "<option selected=selected' value='".$arr[$i]->id."'>".$arr[$i]->cat_name ."</option>";
            }
            else{
              echo "<option value='".$arr[$i]->id."'>".$arr[$i]->cat_name ."</option>";
            }
          }
          ?>
	</select>

</div>
<div class="form-group">
    <label><?php echo $language['item_name']; ?></label>
    <input type="text" class="form-control" placeholder="<?php echo $language['item_name']; ?>"  name="item_name" value="<?php echo $objItem->menu_name; ?>" required >
</div>
<div class="form-group">
    <label><?php echo $language['description']; ?></label>
	<textarea class="form-control" placeholder="<?php echo $language['description']; ?>" name="item_description" required><?php echo $objItem->description ; ?></textarea>
</div>
 <div class="form-group">
    <label><?php echo $language['price']; ?> </label>
    <input type="text" class="form-control" placeholder="<?php echo $language['price']; ?>" name="item_price" value="<?php echo $objItem->price; ?>" required>
</div>
 <div class="form-group">
    <label><?php echo $language['select_image']; ?></label>
	<img class="img-fluid" src="images/menu_item_icon/<?php echo $objItem->menu_image; ?>" width="100px">
    <input type="file" class="form-control"  name="file" >
</div>

