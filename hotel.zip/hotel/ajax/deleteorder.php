<?php
ob_start();
include_once('../classes/DashboardClass.php');
$id = $_GET['id'];
if (DashboardClass::deleteorder($id)) {
return 'true';
}

?>
