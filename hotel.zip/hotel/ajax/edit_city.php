<?php

	include_once('../classes/CityClass.php');
    $id=$_REQUEST['city_edit_id'];
    $objCity=CityClass::getCityById($id);    

include('../language/lang_en.php');   	
?>
<form method="post">
 <input type="hidden" name="id" id="id" value="<?php echo $objCity->id;?>">

<div class="form-group">
    <label class="control-label"><?php echo $language['city_name']; ?></label>
    <input type="text" name="name" class="form-control" id="name" placeholder="City Name" required="" value="<?php echo $objCity->city_name;?>">
</div>
</div>
<div class="col-md-12">
		<div class="col-md-6">
			<input type="submit" name="editcity"  class="btn btn-primary btn-md form-control" value="Edit">
		</div>
		<div class="col-md-6">
			<input type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="Close">
		</div>
	</div>
</form>
