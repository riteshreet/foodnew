<?php

include_once('../classes/Utility.php');
session_start();

 $select_currency = $_POST['select_currency'];
		$sql = mysqli_query($conn,"SELECT * FROM `food_user` where userid='".$_SESSION['uid']."'");
		$total_order_amt = mysqli_fetch_array($sql);
		mysqli_set_charset($conn,"utf8");
		$sq =mysqli_query($conn,"UPDATE `food_user` SET `currency`='".$select_currency."' WHERE `currency`='".$total_order_amt['currency']."'");
?>