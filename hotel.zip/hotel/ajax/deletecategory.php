<?php
$id = $_REQUEST['id'];
include '../classes/CategoryClass.php';
$delete_category = CategoryClass::deletecategory($id);
if($delete_category){
	echo "Delete Successfully";
}
?>