<?php
require_once('../classes/Utility.php');
include('../order_message.php');
$id=$_POST['querystring'];

$query=mysqli_query($conn,"select * from set_order_detail WHERE id='".$id."'");
$row=mysqli_fetch_array($query);
$order_id=$row['id'];
$user_id=$row['user_id'];

$querya=mysqli_query($conn,"select * from food_notification");
$resa=mysqli_fetch_array($querya);
$google_api_key=$resa['android_key'];
$ios_api_key=$resa['ios_key'];

$sendresult = array();
// Notification Data

$query=mysqli_query($conn,"select * from food_tokandata where type='android' AND user_id='".$user_id."'");
$count = mysqli_num_rows($query);
$massage = $preparing_msg;
    
if ($count) {

    $i      = 0;
    $reg_id = array();
    while ($res1 = mysqli_fetch_array($query)) {
        
        $reg_id[$i] = $res1['token'];
        $i++;
    }
     $registrationIds =  $reg_id ;
    
    $message = array(
    	'message' => $massage,
    	'title' => 'Order Status');

    $fields = array(
        'registration_ids'  => $registrationIds,
        'data'      => $message
    );

    $url = 'https://fcm.googleapis.com/fcm/send';

    $headers = array(
        'Authorization: key='.$google_api_key,// . $api_key,
        'Content-Type: application/json'
    );

    $json =  json_encode($fields);
   
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS,$json);

    $result = curl_exec($ch);
   
    if ($result === FALSE){
        die('Curl failed: ' . curl_error($ch));
    }   
    
	curl_close($ch);
    $response=json_decode($result,true);
    if($response['success']>0)
    {
        $sendresult['android'] = $response['success'];
    }
    else
    {
       $sendresult['android'] = 0;
    }
} else {

	$queryios=mysqli_query($conn,"select * from food_tokandata where type='Iphone' AND user_id='".$user_id."'");
	
	$i      = 0;
    $reg_id = array();
    while ($res1 = mysqli_fetch_array($queryios)) {
        
        $reg_id[$i] = $res1['token'];
        $i++;
    }
     $registrationIds =  $reg_id ;


	$msg = array(
	'body'  => $massage,
	'title'     => "Notification",
	'vibrate'   => 1,
	'sound'     => 1,
	);

	$fields = array(
        'registration_ids'  => $registrationIds,
        'notification'      => $msg
    );

	$headers = array(
        'Authorization: key=' . $ios_api_key,
        'Content-Type: application/json'
    );

	$ch = curl_init();
	curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
	curl_setopt( $ch,CURLOPT_POST, true );
	curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
	curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
	curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
	curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
	$result = curl_exec($ch );

    if ($result === FALSE){
        die('Curl failed: ' . curl_error($ch));
    }   

    curl_close($ch);
    $response=json_decode($result,true);
    if($response['success']>0)
    {
        {
            $sendresult['ios'] = $response['success'];
        }
    }
    else
    {
       $sendresult['ios'] = 0;
    }
}

date_default_timezone_set("Asia/Calcutta");
$date = date('d-m-Y H:i');
$update=mysqli_query($conn,"UPDATE `set_order_detail` SET `order_status`= '1',preparing_date_time='".$date."',preparing_status='1' WHERE `id`= '".$id."'");
print_r($update);
exit();
if($update)
{
    echo 1;
} else {
    echo 0;
}
?>