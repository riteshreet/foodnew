<?php
ob_start();
	include_once('../classes/MenuitemClass.php');
	include_once('../classes/CategoryClass.php');
  include_once('../classes/IngredientsClass.php');
    $id=$_REQUEST['id'];
    $objIngre=IngredientsClass::getingreById($id);
	
	include('../language/lang_en.php');  
    
          
?>
 <input type="hidden" name="id" id="id" value="<?php echo $objIngre->id;?>">

 <label><?php echo $language['select_menu_category'];?></label></br>
    <div class="form-group">
      <select  name="ingredients_cat" id="Select" onchange="Function()" class="form-control" required>
        
           <?php
          $arr=CategoryClass::getallcategory();
          for ($i=0; $i < count($arr); $i++) {
            if ($arr[$i]->id == $objIngre->category) {
              echo "<option selected=selected' value='".$arr[$i]->id."'>".$arr[$i]->cat_name ."</option>";
            }
            else{
              echo "<option value='".$arr[$i]->id."'>".$arr[$i]->cat_name ."</option>";
            }
          }
          ?>
      </select>
      
    </div>
    <label><?php echo $language['select_menu_item'];?></label></br>
    <div class="form-group">
      <select name="ingredients_menu" id="submit_menu_name" class="form-control" required >
        <?php
        $arr1 = MenuitemClass::getallmenu();
          for ($i=0; $i < count($arr1); $i++) {
            if ($arr1[$i]->id == $objIngre->menu_id) {
              echo "<option selected=selected' value='".$arr1[$i]->id."'>".$arr1[$i]->menu_name ."</option>";
            }
            
          }
          ?>
      </select>
    </div>

    <label><?php echo $language['item_name']; ?></label>
    <div class="form-group">
       <input type="text" class="form-control" placeholder="Item Name"  name="ingredients_item" value="<?php echo  $objIngre->item_name; ?>" required  >
    </div>
    
    <label><?php echo $language['type']; ?> </label>
    <div class="form-group">
      <div class="radio">
      <?php
        if($objIngre->price==0)
        { ?>
          <label><input value="1" type="radio" onclick="javascript:yesnoChecks();" name="ingredients_type" id="yesChecks" >&nbsp;<?php echo $language['paid'];?></label>
          &nbsp;&nbsp;&nbsp;&nbsp;
          <label><input value="0" type="radio" onclick="javascript:yesnoChecks();" name="ingredients_type" id="yesChecks" checked >&nbsp;<?php echo $language['free'];?></label>
      <?php }
        else
        { ?>
          <label><input value="1" type="radio" onclick="javascript:yesnoChecks();" name="ingredients_type" id="yesChecks" checked >&nbsp;<?php echo $language['paid'];?></label>
          &nbsp;&nbsp;&nbsp;&nbsp;
          <label><input value="0" type="radio" onclick="javascript:yesnoChecks();" name="ingredients_type" id="yesChecks" >&nbsp;<?php echo $language['free'];?></label>
      <?php   }
      ?>
      
      </div>
    </div>

    <?php 
    if($objIngre->price == 0)
    { ?>
      <div class="form-group">
      <div id="ifYess" style="display:none;">
      <label><?php echo $language['item_price']; ?></label>
        <input type="text" id="myTextt" value="<?php echo $objIngre->price; ?>" class="form-control" placeholder="Item Price"  name="ingredients_price" required  >
      </div>
    </div>
  <?php }
    else
    { ?>
      <div class="form-group">
      <div id="ifYess" style="display:block;">
      <label><?php echo $language['item_price']; ?></label>
        <input type="text" id="myTextt" value="<?php echo $objIngre->price; ?>" class="form-control" placeholder="Item Price"  name="ingredients_price" required  >
      </div>
    </div>
  <?php }
    ?>