<?php 

include_once('../classes/AdminClass.php');
include_once('../classes/DashboardClass.php');
include('../language/lang_en.php');  
if(isset($_POST['id']))
{
	$id = $_POST['id'];
	$total_amt_sum=0;

?>

<div>
	<div class="container">
			<?php		
			$cursim = AdminClass::getAdmin('1');
			$set_order_row = DashboardClass::order_detalis($id);
			
			
			
			$string1 = $cursim->currency;
			$val = explode("-",$string1);
			
			if($cursim->currency != "")
				{
					 $cur = $val[1]; 
				}
				else
				{
					 $cur = "$";
				}
		
			?>	
			<div class="modal-header">
				<h5 class="modal-title"><?php echo $language['order_no']; ?>&nbsp;<?php echo $set_order_row->id; ?>&nbsp;-&nbsp;</h5>
				<h5  class="modal-title" id="myamt"></h5><h5  class="modal-title">
				<?php echo $cur; ?>
				</h5>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>

		<?php
	
			$user = DashboardClass::app_user($set_order_row->user_id);
		?>
			<h5 style="border-bottom:1px rgba(0,0,0,.2) solid;padding:6px 0px;">Person Detail</h5> 
			<?php for($i=0;$i<count($user);$i++) { ?>
					<div><b><?php echo  $set_order_row->name; ?></b></div>
					<div><?php echo  $user[$i]->mob_number; ?></div> 
					<div><?php date_default_timezone_set('Asia/Kolkata'); echo $date = date('y-m-d h:i:s'); ?></div>
					<div style="padding-right:120px;"><?php echo  $set_order_row->address; ?></div> </br>
					<div><?php echo $language['payment_type']; ?> <?php echo  $set_order_row->payment_type; ?></div>
					<div><?php echo $language['notes']; ?> <?php echo  $set_order_row->notes; ?></div></br>
				</div>
		<?php }?>
		
		
		<h5><?php echo $language['order_details']; ?></h5> 				
			<table class="table">
				<tbody>
					<tr>
						<th><?php echo $language['item_name']; ?></th>
						<th><?php echo $language['item_qty']; ?></th>
						<th><?php echo $language['price'];?></th>
						<th><?php echo $language['total_price']; ?></th>
					</tr>
					
					<?php 
						$item = DashboardClass::getorderdetalis($id);
						for($i=0;$i<count($item);$i++){
					
					?>		
						<tr>
							<?php 
							$menu_items = DashboardClass::getitemdetalis($item[$i]->item_id);
							for($j=0;$j<count($menu_items);$j++){
							 ?>
								<td>
									<b><?php echo $menu_items[$j]->menu_name; ?></b></br>
									<?php   
										$item_inte_inner = DashboardClass::getint($item[$i]->ingredients_id);
										
										for($k=0;$k<count($item_inte_inner);$k++) 
										{
											echo $item_inte_inner[$k]->item_name."</br>";
										} 
									?> 
								</td>
							
								<td><b><?php echo $item[$i]->item_qty ?></b></td>
								<td>
									<b><?php echo $menu_items[$j]->price.$cur; ?> </b></br>
									<?php
								}
									$item_inte_inner = DashboardClass::getint($item[$i]->ingredients_id);
										for($l=0;$l<count($item_inte_inner);$l++) 
										{	
											if($item_inte_inner[$l]->price == 0)
											{
												echo "---</br>";
											}
											else
											{
												echo $item_inte_inner[$l]->price . $cur."</br>";
											}
										
										} ?> 
								</td>
								<td><?php echo $item[$i]->ItemTotalPrice . $cur ?></td>
						</tr>
							<?php } ?>
						
					
					
				</tbody>
			</table>
	
	</div>

</div>

<?php 
}
?>