<?php
include_once('Utility.php');
include_once('MessageClass.php');
class IngredientsClass{
	static public function getall(){
		$query= "SELECT * from food_ingredients order by id desc";
		$arrIntg=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objIntg=new CategoryClass();
	        $objIntg->id=$obj->id;
	        $objIntg->category=$obj->category;
	        $objIntg->item_name=$obj->item_name;
	        $objIntg->menu_id=$obj->menu_id;
	        $objIntg->price=$obj->price;
	        $objIntg->type=$obj->type;
	        array_push($arrIntg,$objIntg);
	      }
	    }
	    
	    return $arrIntg;	
	}
	static public function getallingr($page1,$page_limit){
		$query= "SELECT * from food_ingredients order by id desc limit $page1,$page_limit";
		$arrIntg=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objIntg=new CategoryClass();
	        $objIntg->id=$obj->id;
	        $objIntg->category=$obj->category;
	        $objIntg->item_name=$obj->item_name;
	        $objIntg->menu_id=$obj->menu_id;
	        $objIntg->price=$obj->price;
	        $objIntg->type=$obj->type;
	        array_push($arrIntg,$objIntg);
	      }
	    }
	    
	    return $arrIntg;
	}
	static public function getTotalingr(){
		$query="SELECT COUNT(id) FROM food_ingredients";
	    if ($result=mysqli_query(Utility::DB_Connection(),$query))
	    {
	      $row=mysqli_fetch_row($result);
	      return $row[0];
	    }
	}
	static public function getallingr_serach($cat,$menu,$page1,$page_limit){
		$query= "SELECT * from food_ingredients where category='".$cat."' and menu_id='".$menu."' order by id desc limit $page1,$page_limit";
		$arrIntg=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objIntg=new CategoryClass();
	        $objIntg->id=$obj->id;
	        $objIntg->category=$obj->category;
	        $objIntg->item_name=$obj->item_name;
	        $objIntg->menu_id=$obj->menu_id;
	        $objIntg->price=$obj->price;
	        $objIntg->type=$obj->type;
	        array_push($arrIntg,$objIntg);
	      }
	    }
	    
	    return $arrIntg;
	}
	static public function getTotalingr_serach($cat,$menu){
		$query="SELECT COUNT(id) FROM food_ingredients where category='".$cat."' and menu_id='".$menu."'";
	    if ($result=mysqli_query(Utility::DB_Connection(),$query))
	    {
	      $row=mysqli_fetch_row($result);
	      return $row[0];
	    }
	}
	static public function serach_data($ing,$cat){
		$query = "SELECT * FROM `food_ingredients` where category='".$cat."' and menu_id='".$ing."'";
		$arrIntg=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objIntg=new CategoryClass();
	        $objIntg->id=$obj->id;
	        $objIntg->category=$obj->category;
	        $objIntg->item_name=$obj->item_name;
	        $objIntg->menu_id=$obj->menu_id;
	        $objIntg->price=$obj->price;
	        $objIntg->type=$obj->type;
	        array_push($arrIntg,$objIntg);
	      }
	    }
	    
	    return $arrIntg;	
	}
	static public function insertNewinteg($obj){
		 $con=Utility::DB_Connection();
    $query = "INSERT INTO `food_ingredients`( `category`, `item_name`, `menu_id`, `price`, `type`) VALUES ('$obj->category','$obj->item_name','$obj->menu_id','$obj->price','$obj->type')";
    mysqli_set_charset($con,'utf8');
    $message=new MessageClass();
    if ($GLOBALS['demo']!="YES") {
      if ($result=mysqli_query($con,$query))
      {
        $message->status = 1;
        $message->message = "New Menu successfully added";
        return $message;
      }
      else {
        $message->status = 0;
        $message->message = mysqli_error($con);
        return $message;
      }
    }
    else{
      $message->status = 0;
      $message->message = "Demo user can't insert new category.";
      return $message;
    }

	}
	static public function getingreById($id){
		 $query="SELECT  * FROM food_ingredients  WHERE id='$id'";
    $con=Utility::DB_Connection();

    mysqli_set_charset($con,'utf8');

    $objIntg=new IngredientsClass();

    if ($result=mysqli_query($con,$query))
    {
      while ($obj=mysqli_fetch_object($result))
      {

        	$objIntg->id=$obj->id;
	        $objIntg->category=$obj->category;
	        $objIntg->item_name=$obj->item_name;
	        $objIntg->menu_id=$obj->menu_id;
	        $objIntg->price=$obj->price;
	        $objIntg->type=$obj->type;
      }
    }
    return $objIntg;
	}
	static public function updateingre($obj,$id){
	$query = "UPDATE `food_ingredients` SET `category`='$obj->category',`item_name`='$obj->item_name',`menu_id`='$obj->menu_id',`price`='$obj->price',`type`='$obj->type'  WHERE id=$id";
    
    $con=Utility::DB_Connection();
    mysqli_set_charset($con,'utf8');
    $objMessage=new MessageClass();
    if ($GLOBALS['demo']!="YES") {
      if ($result=mysqli_query($con,$query))
      {
        $objMessage->status=1;
        $objMessage->message="New category successfully updated.";
        return $objMessage;
      }
      else {
        $objMessage->status=0;
        $objMessage->message=mysqli_error($con);
        return $objMessage;
      }
    }
    else{
      $objMessage->status=0;
      $objMessage->message="Demo user can't update category.";
      return $objMessage;
    }
  } 
	
}	
?>