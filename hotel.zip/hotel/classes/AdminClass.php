<?php include_once('Utility.php');
class AdminClass{

  public $id, $username,$email,$password;
  static public function authenticateAdmin($username,$password)
  {
    $myusername = stripslashes($username);
    $mypassword = stripslashes($password);
    $myusername = mysqli_real_escape_string(Utility::DB_Connection(),$myusername);
    $mypassword = mysqli_real_escape_string(Utility::DB_Connection(),$mypassword);

    $query="SELECT * FROM food_user WHERE email='$myusername' and password='$mypassword'";
   
    $con=Utility::DB_Connection();
            mysqli_set_charset($con,'utf8');
            $result=mysqli_query($con,$query);
            $count=mysqli_num_rows($result);
            foreach ($result as $rows)
            {
             
              
                $array = $rows;

            }
    if($count==1){
      $_SESSION['uid']=$rows['userid'];
     
      return true;
    }
    else {
      return false;
    }
    ob_end_flush();
  }
  static public function getAdmin($id)
  {
    $query="SELECT `userid`, `user_name`, `email`,`password` ,`currency` FROM `food_user` WHERE `userid`='$id'";
    $con=Utility::DB_Connection();

    mysqli_set_charset($con,'utf8');

    $objAdmin=new AdminClass();

    if ($result=mysqli_query($con,$query))
    {
      while ($obj=mysqli_fetch_object($result))
      {
        $objAdmin->userid=$obj->userid;
        $objAdmin->user_name=$obj->user_name;
        $objAdmin->email=$obj->email;
        $objAdmin->currency=$obj->currency;
        $objAdmin->password=$obj->password;
      }
    }
    return $objAdmin;
  }
  static public function getAdminData()
  {
    $query="SELECT `userid`, `user_name`, `email`,`password` FROM `food_user`";
    $con=Utility::DB_Connection();

    mysqli_set_charset($con,'utf8');

    $objAdmin=new AdminClass();

    if ($result=mysqli_query($con,$query))
    {
      while ($obj=mysqli_fetch_object($result))
      {
        $objAdmin->id=$obj->id;
        $objAdmin->user_name=$obj->user_name;
        $objAdmin->email=$obj->email;
        $objAdmin->currency=$obj->currency;
        $objAdmin->password=$obj->password;
      }
    }
    return $objAdmin;
  }
}
?>
