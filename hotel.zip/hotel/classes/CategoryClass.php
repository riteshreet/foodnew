<?php
include_once('Utility.php');
include_once('MessageClass.php');
class CategoryClass{
	static public function getallcategory(){
		$query= "SELECT * from food_category order by id desc";
		$arrCategory=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objCategory=new CategoryClass();
	        $objCategory->id=$obj->id;
	        $objCategory->cat_icon=$obj->cat_icon;
	        $objCategory->cat_name=$obj->cat_name;
	        array_push($arrCategory,$objCategory);
	      }
	    }
	    
	    return $arrCategory;
	}
  static public function getallcat($page1,$page_limit){
    $query= "SELECT * from food_category  order by id desc limit $page1,$page_limit";
    $arrCategory=Array();
      $con=Utility::DB_Connection();

      mysqli_set_charset($con,'utf8');
      //return $query;
      if ($result=mysqli_query($con,$query))
      {
        while ($obj=mysqli_fetch_object($result))
        {
          $objCategory=new CategoryClass();
          $objCategory->id=$obj->id;
          $objCategory->cat_icon=$obj->cat_icon;
          $objCategory->cat_name=$obj->cat_name;
          array_push($arrCategory,$objCategory);
        }
      }
      
      return $arrCategory;
  }
  static public function getTotalcategory(){
    $query="SELECT COUNT(id) FROM food_category";
    if ($result=mysqli_query(Utility::DB_Connection(),$query))
    {
      $row=mysqli_fetch_row($result);
      return $row[0];
    }
  }
  static public function getallcat_serach($serach,$page1,$page_limit){
    $query= "SELECT * from food_category where cat_name  like '%". $serach."%'  order by id desc limit $page1,$page_limit";
    // echo $query;
    $arrCategory=Array();
      $con=Utility::DB_Connection();

      mysqli_set_charset($con,'utf8');
      //return $query;
      if ($result=mysqli_query($con,$query))
      {
        while ($obj=mysqli_fetch_object($result))
        {
          $objCategory=new CategoryClass();
          $objCategory->id=$obj->id;
          $objCategory->cat_icon=$obj->cat_icon;
          $objCategory->cat_name=$obj->cat_name;
          array_push($arrCategory,$objCategory);
        }
      }
      
      return $arrCategory;
  }
  static public function getTotalcategory_serach($serach){
    $query="SELECT COUNT(id) FROM food_category where cat_name  like '%". $serach."%' ";
    if ($result=mysqli_query(Utility::DB_Connection(),$query))
    {
      $row=mysqli_fetch_row($result);
      return $row[0];
    }
  }
	static public function insertNewCategory($obj){
    $con=Utility::DB_Connection();
    $strName=addslashes($obj->cat_name);
   
    $query = "INSERT INTO `food_category`(`cat_name`,`cat_icon`) VALUES ('$strName','$obj->cat_icon')";
    mysqli_set_charset($con,'utf8');
    $message=new MessageClass();
    // if ($GLOBALS['demo']!="YES") {
      if ($result=mysqli_query($con,$query))
      {
        $message->status = 1;
        $message->message = "New category successfully added";
        return $message;
      }
      else {
        $message->status = 0;
        $message->message = mysqli_error($con);
        return $message;
      }
    // }
    // else{
    //   $message->status = 0;
    //   $message->message = "Demo user can't insert new category.";
    //   return $message;
    // }
  }
   static public function getcategory($id)
  {
    $query="SELECT `id`, `cat_name`,`cat_icon` FROM food_category WHERE id='$id'";
    $con=Utility::DB_Connection();

    mysqli_set_charset($con,'utf8');

    $objCategory=new CategoryClass();

    if ($result=mysqli_query($con,$query))
    {
      while ($obj=mysqli_fetch_object($result))
      {

        $objCategory->id=$obj->id;
        $objCategory->cat_name=$obj->cat_name;
        $objCategory->cat_icon=$obj->cat_icon;
      }
    }
    return $objCategory;
  }
  static public function updateCategory($obj,$id){
    //$strName=addslashes($obj->name);
    $query = "UPDATE `food_category` SET `cat_name`='$obj->cat_name', `cat_icon`='$obj->cat_icon' WHERE id=$id";
      
    $con=Utility::DB_Connection();
    mysqli_set_charset($con,'utf8');
    $objMessage=new MessageClass();
    if ($GLOBALS['demo']!="YES") {
      if ($result=mysqli_query($con,$query))
      {
        $objMessage->status=1;
        $objMessage->message="New category successfully updated.";
        return $objMessage;
      }
      else {
        $objMessage->status=0;
        $objMessage->message=mysqli_error($con);
        return $objMessage;
      }
    }
    else{
      $objMessage->status=0;
      $objMessage->message="Demo user can't update category.";
      return $objMessage;
    }
  } 
  static public function getCategoryById($id){
     $query="SELECT * FROM food_category WHERE id='$id'";
    $con=Utility::DB_Connection();

    mysqli_set_charset($con,'utf8');

    $objCategory=new CategoryClass();

    if ($result=mysqli_query($con,$query))
    {
      while ($obj=mysqli_fetch_object($result))
      {

        $objCategory->id=$obj->id;
      }
    }
    return $objCategory;
  }
  static public function deletecategory($id){
    $obj=self::getcategory($id);// This will get all detail of category
    
    $query="delete from food_category where id = '$id'";
    $con=Utility::DB_Connection();
    mysqli_set_charset($con,'utf8');
    if ($GLOBALS['demo']!="YES") {
      if ($result=mysqli_query($con,$query))
      {
        $file_path="../images/menu_cat_icon/$obj->cat_icon";
        unlink($file_path);
        return true;
      }
      else{
        return false;
      }
    }
    else{
      header('location:../menu_category.php');
    }
  }  
}
?>