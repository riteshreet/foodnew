<?php
@ob_start();

$GLOBALS['db_host']='localhost';
$GLOBALS['db_user']='root';
$GLOBALS['db_pass']='';
$GLOBALS['db_name']='db_test_restaurant';
 ?>


