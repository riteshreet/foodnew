<?php
class MessageClass{
  public $status,$message;

  static public function showMessage($objMessage){
    if ($objMessage->status == 1) {
      ?>
      <div class="alert alert-success" id='alert' style="margin:5px" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong>Success!</strong> <?php echo $objMessage->message ?></div>
      <?php
    }
    else{
      ?>
      <div class="alert alert-danger" style="margin:5px" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <strong>Fail!</strong> <?php echo $objMessage->message ?></div>
      <?php
    }
  }
}
?>
