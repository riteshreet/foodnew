<?php
include_once('Utility.php');
include_once('MessageClass.php');
class DeliveryboyClass{
	static public function getall(){
		$query= "SELECT * from food_delivery_boy order by id desc";
		$arrDeliveryboy=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objDeliveryboy=new DeliveryboyClass();
	        $objDeliveryboy->id=$obj->id;
	        $objDeliveryboy->create_at=$obj->create_at;
	        $objDeliveryboy->name=$obj->name;
          $objDeliveryboy->email=$obj->email;
          $objDeliveryboy->vehicle_no=$obj->vehicle_no;
          $objDeliveryboy->vehicle_type=$obj->vehicle_type;
          $objDeliveryboy->mobile_no=$obj->mobile_no;
	        array_push($arrDeliveryboy,$objDeliveryboy);
	      }
	    }
	    
	    return $arrDeliveryboy;
	}
  static public function getallboy($page1,$page_limit){
    $query= "SELECT * from food_delivery_boy order by id desc limit $page1,$page_limit";
    $arrDeliveryboy=Array();
      $con=Utility::DB_Connection();

      mysqli_set_charset($con,'utf8');
      //return $query;
      if ($result=mysqli_query($con,$query))
      {
        while ($obj=mysqli_fetch_object($result))
        {
          $objDeliveryboy=new DeliveryboyClass();
          $objDeliveryboy->id=$obj->id;
          $objDeliveryboy->create_at=$obj->create_at;
          $objDeliveryboy->name=$obj->name;
          $objDeliveryboy->email=$obj->email;
          $objDeliveryboy->vehicle_no=$obj->vehicle_no;
          $objDeliveryboy->vehicle_type=$obj->vehicle_type;
          $objDeliveryboy->mobile_no=$obj->mobile_no;
          array_push($arrDeliveryboy,$objDeliveryboy);
        }
      }
      
      return $arrDeliveryboy;
  }
  static public function getTotalboy(){
    $query="SELECT COUNT(id) FROM food_delivery_boy";
      if ($result=mysqli_query(Utility::DB_Connection(),$query))
      {
        $row=mysqli_fetch_row($result);
        return $row[0];
      }
  }
   static public function getallboy_serach($serach,$page1,$page_limit){
    $query= "SELECT * from food_delivery_boy where name like '%". $serach."%'  order by id desc limit $page1,$page_limit";
    $arrDeliveryboy=Array();
      $con=Utility::DB_Connection();

      mysqli_set_charset($con,'utf8');
      //return $query;
      if ($result=mysqli_query($con,$query))
      {
        while ($obj=mysqli_fetch_object($result))
        {
          $objDeliveryboy=new DeliveryboyClass();
          $objDeliveryboy->id=$obj->id;
          $objDeliveryboy->create_at=$obj->create_at;
          $objDeliveryboy->name=$obj->name;
          $objDeliveryboy->email=$obj->email;
          $objDeliveryboy->vehicle_no=$obj->vehicle_no;
          $objDeliveryboy->vehicle_type=$obj->vehicle_type;
          $objDeliveryboy->mobile_no=$obj->mobile_no;
          array_push($arrDeliveryboy,$objDeliveryboy);
        }
      }
      
      return $arrDeliveryboy;
  }
  static public function getTotalboy_serach($serach){
    $query="SELECT COUNT(id) FROM food_delivery_boy where name like '%". $serach."%'";
      if ($result=mysqli_query(Utility::DB_Connection(),$query))
      {
        $row=mysqli_fetch_row($result);
        return $row[0];
      }
  }
	static public function insertNewBoy($obj){
    $con=Utility::DB_Connection();
  
   
    $query = "INSERT INTO `food_delivery_boy`(`action`, `create_at`, `email`, `mobile_no`, `name`, `password`, `vehicle_no`, `vehicle_type`,`attendance`) VALUES ('0','$obj->create_at','$obj->email','$obj->mobile_no','$obj->name','$obj->password','$obj->vehicle_no','$obj->vehicle_type','')";
    mysqli_set_charset($con,'utf8');
    $message=new MessageClass();
    if ($GLOBALS['demo']!="YES") {
      if ($result=mysqli_query($con,$query))
      {
        $message->status = 1;
        $message->message = "New Delivery Boy successfully added";
        return $message;
      }
      else {
        $message->status = 0;
        $message->message = mysqli_error($con);
        return $message;
      }
    }
    else{
      $message->status = 0;
      $message->message = "Demo user can't insert new Delivery Boy.";
      return $message;
    }
  }
  
}
?>