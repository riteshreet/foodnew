<?php include_once('Utility.php');
class DashboardClass{
	static public function count_todayorder(){
		  $today_date = date("d-m-Y");
		  $query="SELECT * FROM set_order_detail where order_placed_date LIKE '%$today_date%'";
	
          $con=Utility::DB_Connection();
          mysqli_set_charset($con,'utf8');
          $result=mysqli_query($con,$query);
          $count=mysqli_num_rows($result);
          return $count;
	}
	static  public function count_totalorder(){
		  $query="SELECT * FROM set_order_detail";
          $con=Utility::DB_Connection();
          mysqli_set_charset($con,'utf8');
          $result=mysqli_query($con,$query);
          $count=mysqli_num_rows($result);
          if ($count) {
          	
            return $count;
              
          } else {
              return 0;
          }	
	}
	static public function count_accpetedorder(){
		  $query="SELECT * FROM set_order_detail where NOT order_status = 0";
          $con=Utility::DB_Connection();
          mysqli_set_charset($con,'utf8');
          $result=mysqli_query($con,$query);
          $count=mysqli_num_rows($result);
          if ($count) {
          	
            return $count;
              
          } else {
              return 0;
          }	
	}
	static public function total_order(){
		$query= "SELECT * from set_order_detail order by id desc";
		$arrOrder=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objorder=new DashboardClass();
	        $objorder->id=$obj->id;
	        $objorder->name = $obj->name;
	        $objorder->address = $obj->address;
	        $objorder->user_id=$obj->user_id;
	        $objorder->order_status=$obj->order_status;
	        array_push($arrOrder,$objorder);
	      }
	    }
	    
	    return $arrOrder;
	}
	static public function getAllOrder($page1,$page_limit){
		$query= "SELECT * from set_order_detail  order by id desc limit $page1,$page_limit";
		$arrOrder=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objorder=new DashboardClass();
	        $objorder->id=$obj->id;
	        $objorder->name = $obj->name;
	        $objorder->address = $obj->address;
	        $objorder->user_id=$obj->user_id;
	        $objorder->order_status=$obj->order_status;
	        array_push($arrOrder,$objorder);
	      }
	    }
	    
	    return $arrOrder;
	}
	static public function getTotalOrder(){
	    $query="SELECT COUNT(id) FROM set_order_detail";
	    if ($result=mysqli_query(Utility::DB_Connection(),$query))
	    {
	      $row=mysqli_fetch_row($result);
	      return $row[0];
	    }
	}
	static public function app_user($id){
		$query= "SELECT * FROM `app_user` where id='".$id."'";
		$arrOrder=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objorder=new DashboardClass();
	        $objorder->id=$obj->id;
	       
	        $objorder->mob_number=$obj->mob_number;
	       
	        array_push($arrOrder,$objorder);
	      }
	    }
	    
	    return $arrOrder;
	}
	static public function app_user_data(){
		$query= "SELECT * from app_user order by id desc";
		$arrUser=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objUser=new DashboardClass();
	        $objUser->id=$obj->id;
	       
	        $objUser->mob_number=$obj->mob_number;
	        $objUser->create_at=$obj->create_at;
	        array_push($arrUser,$objUser);
	      }
	    }
	    
	    return $arrUser;
	}
	static public function getalluser($page1,$page_limit){
		$query= "SELECT * from app_user order by id desc limit $page1,$page_limit";
		$arrUser=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objUser=new DashboardClass();
	        $objUser->id=$obj->id;
	       
	        $objUser->mob_number=$obj->mob_number;
	        $objUser->create_at=$obj->create_at;
	        array_push($arrUser,$objUser);
	      }
	    }
	    
	    return $arrUser;
	}
	static public function getTotaluser(){
		$query="SELECT COUNT(id) FROM app_user";
	    if ($result=mysqli_query(Utility::DB_Connection(),$query))
	    {
	      $row=mysqli_fetch_row($result);
	      return $row[0];
	    }
	}
	static public function getalluser_serach($search,$page1,$page_limit){
		$query= "SELECT * from app_user where mob_number like '%". $search."%' order by id desc limit $page1,$page_limit";
		$arrUser=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objUser=new DashboardClass();
	        $objUser->id=$obj->id;
	       
	        $objUser->mob_number=$obj->mob_number;
	        $objUser->create_at=$obj->create_at;
	        array_push($arrUser,$objUser);
	      }
	    }
	    
	    return $arrUser;
	}
	static public function getallcity($page1,$page_limit){
		$query= "SELECT * from food_city order by id desc limit $page1,$page_limit";
		$arrUser=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objUser=new DashboardClass();
	        $objUser->id=$obj->id;
	       
	        $objUser->city_name=$obj->city_name;
	       
	        array_push($arrUser,$objUser);
	      }
	    }
	    
	    return $arrUser;
	}
	static public function getTotalcity(){
		$query="SELECT COUNT(id) FROM food_city";
	    if ($result=mysqli_query(Utility::DB_Connection(),$query))
	    {
	      $row=mysqli_fetch_row($result);
	      return $row[0];
	    }
	}
	static public function getTotaluser_serach($search){
		 $query="SELECT COUNT(id) FROM app_user where mob_number like '%". $search."%'";
	    if ($result=mysqli_query(Utility::DB_Connection(),$query))
	    {
	      $row=mysqli_fetch_row($result);
	      return $row[0];
	    }
	}
	static public function order_detalis($id){
		$query= "SELECT * FROM `set_order_detail` where id='".$id."'";
		
    	$con=Utility::DB_Connection();
		$objorder = new DashboardClass();
	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {

	         $objorder->id=$obj->id;
	        $objorder->user_id=$obj->user_id;
	        $objorder->address=$obj->address;
	        $objorder->notes=$obj->notes;
	        $objorder->payment_type=$obj->payment_type;
	        $objorder->name=$obj->name;
	        $objorder->order_status=$obj->order_status;
	        
	      }
	    }
	    
	    return $objorder;
	}
	static public function getorderdetalis($id){
		$query= "SELECT * FROM `fooddelivery_food_desc` where set_order_id='".$id."'";

    	$con=Utility::DB_Connection();
		$arrOrder=Array();
	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	      	$objorder = new DashboardClass();
	        $objorder->id=$obj->id;
	        $objorder->ingredients_id=$obj->ingredients_id;
	        $objorder->item_amt=$obj->item_amt;
	        $objorder->item_id=$obj->item_id;
	        $objorder->item_qty=$obj->item_qty;
	        $objorder->ItemTotalPrice=$obj->ItemTotalPrice;
	        $objorder->set_order_id=$obj->set_order_id;
	         array_push($arrOrder,$objorder);
	      }
	    }
	    
	    return $arrOrder;
	}
	
	static public function getitemdetalis($id){
		$query= "SELECT * FROM `food_menu` where id='".$id."'";
		
    	$con=Utility::DB_Connection();
		$arrOrder=Array();
	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	      	$objorder = new DashboardClass();
	        $objorder->id=$obj->id;
	        $objorder->description=$obj->description;
	        $objorder->menu_image=$obj->menu_image;
	        $objorder->menu_name=$obj->menu_name;
	        $objorder->price=$obj->price;
	         array_push($arrOrder,$objorder);
	      
	      }
	    }
	    
	    return $arrOrder;
	}
	static public function getint($id){
		$query="SELECT * FROM `food_ingredients` where id IN(".$id.")";
			$con=Utility::DB_Connection();
		$arrOrder=Array();
	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	      	$objorder = new DashboardClass();
	        $objorder->id=$obj->id;
	        $objorder->item_name=$obj->item_name;
	        $objorder->menu_id=$obj->menu_id;
	        $objorder->price=$obj->price;
	        $objorder->type=$obj->type;
	         array_push($arrOrder,$objorder);
	      
	      }
	    }
	    
	    return $arrOrder;
	}
	static public function deleteorder($id){	
		$query = "DELETE FROM `set_order_detail` WHERE `id` = '$id'";

	    $con=Utility::DB_Connection();
	    mysqli_set_charset($con,'utf8');
	    if ($GLOBALS['demo']!="YES"){
	     
	      if ($result=mysqli_query($con,$query))
	      {
	       
	      return true;
	      }
	      else{
	        return false;
	      }
	    }
		
	}
	
}
