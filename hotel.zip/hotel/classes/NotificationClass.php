<?php
include_once('Utility.php');
include_once('MessageClass.php');
class NotificationClass{
	static public function getall($page1,$page_limit){
		$query= "SELECT * from food_send_notification order by id desc limit $page1,$page_limit";
		$arrNotification=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objNotification=new NotificationClass();
	        $objNotification->id=$obj->id;
	        $objNotification->message=$obj->message;
	        
	        array_push($arrNotification,$objNotification);
	      }
	    }
	    
	    return $arrNotification;
	}
	static public function getTotalnoti(){
		$query="SELECT COUNT(id) FROM food_send_notification";
      if ($result=mysqli_query(Utility::DB_Connection(),$query))
      {
        $row=mysqli_fetch_row($result);
        return $row[0];
      }
	}
	
}
?>