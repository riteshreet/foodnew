<?php
include_once('Utility.php');
include_once('MessageClass.php');
class CityClass{
	static public function getcity(){
		$query= "SELECT * from food_city order by id desc";
		$arrCity=Array();
    	$con=Utility::DB_Connection();

	    mysqli_set_charset($con,'utf8');
	    //return $query;
	    if ($result=mysqli_query($con,$query))
	    {
	      while ($obj=mysqli_fetch_object($result))
	      {
	        $objCity=new CityClass();
	        $objCity->id=$obj->id;
	        $objCity->city_name=$obj->city_name;
	       
	        array_push($arrCity,$objCity);
	      }
	    }
	    
	    return $arrCity;
	}
	static public function insertNewCity($obj){
    $con=Utility::DB_Connection();
 
   
    $query = "INSERT INTO `food_city`(`city_name`) VALUES ('$obj->city_name')";
    mysqli_set_charset($con,'utf8');
    $message=new MessageClass();
    if ($GLOBALS['demo']!="YES") {
      if ($result=mysqli_query($con,$query))
      {
        $message->status = 1;
        $message->message = "New city successfully added";
        return $message;
      }
      else {
        $message->status = 0;
        $message->message = mysqli_error($con);
        return $message;
      }
    }
    else{
      $message->status = 0;
      $message->message = "Demo user can't insert new city.";
      return $message;
    }
  }
  static public function getCityById($id){
  	 $query="SELECT * FROM food_city WHERE id='$id'";
    $con=Utility::DB_Connection();

    mysqli_set_charset($con,'utf8');

    $objCity=new CityClass();

    if ($result=mysqli_query($con,$query))
    {
      while ($obj=mysqli_fetch_object($result))
      {

        $objCity->id=$obj->id;
        $objCity->city_name=$obj->city_name;
       
      }
    }
    return $objCity;

  }
}
?>	