<?php include_once('constant.php');
include_once('MessageClass.php');

$GLOBALS['button']= '';
class Utility{
  static public function DB_Connection()
  {
    return mysqli_connect($GLOBALS['db_host'],$GLOBALS['db_user'],$GLOBALS['db_pass'],$GLOBALS['db_name']);
  }

}
$conn=Utility::DB_Connection();
mysqli_set_charset($conn,"utf8");
?>
