<?php

//breadcrumbs


$language['food_shastra_admin'] = "Food Shastra Admin";
$language['reset'] = "Reset";
$language['next'] = "Next";

$language['dashboard'] = "Dashboard";
// orderdetails


$language['today_order'] = "Today Order";	
$language['total_order'] = "Total Order";
$language['total_accepted_order'] = "Total Accepted Order";




//left-panel
//nav-bar-menu

$language['menu_category'] = "Menu Category";	
$language['menu_item'] = "Menu Item";
$language['menu_ingredients'] = "Menu Ingredients";	
$language['app_user'] = "App User";	
$language['app_review'] = "App Review";	
$language['delivery_boy'] = "Delivery Boy";


//city


$language['city'] = "City";
$language['add_city'] = "Add City";
$language['edit_city'] = "Edit City";
 
	
//ingredients


$language['ingredients_item'] = "Ingredients Item";
$language['select_category'] = "Select Category";
$language['select_menu_item'] = "Select Menu Item";
$language['add_menu_ingredients'] = "Add Menu Ingredients";
$language['select_menu_category'] = "Select Menu Category";
$language['item_name'] = "Item Name";
$language['type'] = "Type";
$language['price'] = "Price";
$language['item_price'] = "Item Price";
$language['edit_menu_ingredients'] = "Edit Menu Ingredients";
$language['ingredients_name'] = "Ingredients Name";
$language['delete'] = "Delete";
$language['free'] = "Free";
$language['paid'] = "Paid";
$language['sort'] = "Sort";


//left-panel
//notification menu

$language['send_notification'] = "Send Notification";	
$language['android_notification'] = "Android Notification";
$language['notification_title'] = "Notification";
$language['notification'] = "Notification";
$language['android_server_key'] = "Android server key";


$language['ios_notification'] = "IOS Notification";	
$language['ios_server_key'] = "IOS server key";


//left-panel 
//currency

$language['currency'] = "CURRENCY";	
$language['currency_small'] = "Currency";	

//content
//card

$language['data_table'] = "Data Table";
$language['search_btn'] = "Search";

$language['name'] = "Name";
$language['address'] = "Address";

$language['more_details'] = "More Details";
$language['more_details_btn'] = "More";

$language['action'] = "Action";
$language['in_pickup_btn'] = "In Pickup";

//end content

//page btn and msg


$language['delete_btn'] = "Delete";
$language['edit_btn'] = "Edit";
$language['choose_file_btn'] = "Choose File";
$language['add_btn'] = "Add";
$language['close_btn'] = "Close";
$language['save_changes_btn'] = "Save Changes";
$language['send_btn'] = "Send";	


//commmon-form-detils

$language['name'] = "Name";
$language['email'] = "Email";
$language['password'] = "Password";
$language['contact_no'] = "Contact No";
$language['message'] = "Message";
$language['image'] = "Image"; 
$language['select_category'] = "Select Category"; 
$language['sign_in'] = "Sign in";

//all navbar menu page form-btn 
	
$language['add_menu_category'] = "Add Menu Category";

//form-title &&& othrs name  dashboard

$language['order_no'] = "Order No:";
$language['person_details'] = "Person Detail";
$language['order_details'] = "Order Detail";
$language['item_name'] = "Item Name";
$language['item_qty'] = "Item Qty";
$language['price'] = "Price";
$language['total_price'] = "Total Price";
$language['payment_type'] = "Payment Type :";
$language['notes'] = "Notes :";



//form-title &&& othrs name  menu- && menu-category


$language['add_menu_category'] = "Add Menu Category";
$language['id'] = "Id";
$language['menu_name'] = "Menu Name";
$language['menu_icon'] = "Menu Icon";	
$language['category_name'] = "Category Name";
$language['category_icon'] = "Category Icon";
$language['category_image'] = "Category Image";
$language['selected_image'] = "Selected Image";
$language['add_menu_category'] = "Add Menu Category";


//form-title &&& othrs name  menu- && menu-item

$language['add_menu_item'] = "Add Menu Item";
$language['item_name'] = "Item Name"; 
$language['category'] = "Category";
$language['description'] = "Description"; 
$language['price'] = "Price";
$language['image'] = "Image";  
$language['select_image'] = "Select Image"; 

//form-title &&& othrs name  menu- && app-user

$language['mobile_number'] = "Mobile Number";

//form-title &&& othrs name  menu- && delivery-boy

$language['add_delivery_boy'] = "Add Delivery Boy";
$language['contact_no'] = "Contact No";
$language['vehicle_no'] = "Vehicle No";
$language['vehicle_type'] = "Vehicle Type";
$language['created_at'] = "Created At";
$language['username'] = "Username";


//---left-panel end-----

//extra after add formmodel name

$language['assign_order_btn']  = "Assign Order";
$language['assign_btn']  = "Assign";
$language['in_pickup_btn']  = "In Pickup";
$language['rejected_btn']  = "Rejected";
$language['out_of_delivery_btn']  = "Out Of Delivery";
$language['invalid_username_or_password']  = "Invalid username or password";
$language['food_shastra']  = "Food Shastra";
$language['admin']  = "Admin";
$language['select_an_option'] = "Select An Option";

$language['edit_menu_category'] = "Edit Menu Category";

$language['logout']  = "Logout";
$language['login']  = "Login";

$language['my_profile']  = "My Profile";
$language['profile']  = "Profile";

$language['profile_update_msg']  = "Your Profile Update.";
$language['email_address']  = "Email Address";


$language['android_success_msg']  = "Your Android google server key successfully Save Changes.";
$language['android_success_msg']  = "Your Android google server key successfully Save Changes.";

$language['successfull']  = "successfull!";

$language['assign_order_delivery_Boy']  = "Assign Order to Delivery Boy!";

$language['email_id']  = "Email ID";

// other in ajax//

$language['order_id']  = "Order ID";
$language['select_delivery_boy']  = "Select Delivery Boy";

$language['select_name']  = "Select Name";
$language['select_menu_category'] = "Select Menu Category";
$language['select_menu_item'] = "Select Menu Item";
$language['item_name'] = "Item Name";


$language['accept'] = 'Accept';
$language['reject'] = 'Reject';
$language['menu_image'] = 'Menu Image';
$language['add_menu_image'] = 'Add Menu Image';
$language['select_item'] = 'Select Item';
$language['add_image'] = 'Add Image';

$language['city_name'] = "City Name";
?>
