<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->

<?php 
@session_start();
if(!isset($_SESSION['uid'])){
    echo "<script>window.location='index.php'</script>";
    session_destroy();
}
require_once('classes/DashboardClass.php');
include_once('language/lang_en.php');
require_once('header_link.php');
include_once('pagination.php');
$page_limit=10;
if (isset($_GET['page'])) {
  $page=$_GET['page'];
}
else {
  $page=1;
}
if ($page=='' || $page==1) {
  $page1=0;
}
else{
  $page1=($page*$page_limit)-$page_limit;
}

$row=DashboardClass::getallcity($page1,$page_limit);
$getTotalcity=DashboardClass::getTotalcity();  	

?>
<?php require_once('side_menu.php'); ?> 

<?php
if(isset($_POST["add_city"]))
{
	$city = $_POST['city'];
	$sql = mysqli_query($conn,"INSERT into `food_city`(`city_name`) VALUES ('$city')");
	echo "<script>window.location.href='city.php';</script>";			
}
if(isset($_POST["editcity"]))
{
	$city_edit_id = $_POST['id'];
	$edit_city = $_POST['name'];
	$sql_edit = mysqli_query($conn,"UPDATE `food_city` SET `city_name`= '$edit_city' WHERE `id`= '$city_edit_id'");
	echo "<script>window.location.href='city.php';</script>";		
}

if(isset($_GET['delete_city']))
	{
		$delete_city =$_GET['delete_city'];
		
		$sql_delete_city = mysqli_query($conn,"DELETE FROM `food_city` WHERE `id`=".$delete_city."");
		
		echo "<script>window.location.href='city.php';</script>";
	}
?>

<div id="right-panel" class="right-panel">
	<?php require_once('header.php'); ?> 
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo $language['city']; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active"><?php echo $language['city']; ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

	
		
<div class="content mt-3">
	<div class="animated">
		<div class="breadcrumbs">  
            <div class="page-header float-left">
                <div class="page-title">
                    <h1><button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#myModal"><?php echo $language['add_city']; ?></button></h1>
                </div>
            </div>
        </div>

		<div class="modal fade" id="myModal" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title"><?php echo $language['add_city']; ?></h5>
							<button type="button" class="close" data-dismiss="modal">&times;</button>
						</div>
						<div class="modal-body">
							<form name="menu_form_category" action="" method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label><?php echo $language['city']; ?></label>
									<input type="text" class="form-control" placeholder="<?php echo $language['city']; ?>" name="city" >
								</div>
								<div class="col-md-12">
									<div class="col-md-6">
										<input type="submit" name="add_city"  class="btn btn-primary btn-md form-control" value="<?php echo $language['add_btn']; ?>">
									</div>
									<div class=" col-md-6">
										<input type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="<?php echo $language['close_btn']; ?>">
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
		<div class="modal fade" id="city_edit_Modal" role="dialog">
			<div class="modal-dialog">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-content">
							<div class="modal-header">
								<h5 class="modal-title"><?php echo $language['edit_city']; ?></h5>
								<button type="button" class="close" data-dismiss="modal">&times;</button>
							</div>
							<div class="modal-body" id="edit_city_form">
								
							</div>

						</div>
					</div>
			</div>
			</div>
		</div>
</div>
		
	<div class="content mt-3">
        <div class="animated fadeIn">
            <div class="row">
				<div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title"><?php echo $language['data_table'] ?></strong>
                        </div>
                        <div class="card-body">
                        	<?php if($row) { ?>
							<table class="table table-striped table-bordered">
								<thead>
								  <tr>
									<th>#</th>
									<th><?php echo $language['city']; ?></th>
									<th><?php echo $language['action'] ?></th>
								  </tr>
								</thead>
								<tbody>
									<?php
									$t = 1;	
									for($i=0;$i<count($row);$i++) 
									{ ?>
											<tr>
												<td><?php echo  $t; ?></td>
												<td><?php echo  $row[$i]->city_name; ?></td>
												
												<td>
													<?php if($GLOBALS['button'] == 'YES') { ?>
													<a class="btn btn-md btn-danger " href="" onClick="return confirm('This function is currently disable as it is only a demo website, in your admin it will work perfect')"><?php echo $language['delete_btn']; ?></a>
														
													<a href="" onClick="return confirm('This function is currently disable as it is only a demo website, in your admin it will work perfect')" class="btn btn-md btn-info"><?php echo $language['edit_btn']; ?></a>
													<?php } else { ?>
													<a href="city.php?delete_city=<?php echo $row[$i]->id; ?>" onclick="return confirm('Are you sure you want to delete?')" class="btn btn-md btn-danger "><?php echo $language['delete_btn'] ?></a> 
													
													<button id="mySelect" onclick="myFunction(<?php echo  $row[$i]->id; ?>)" type="button" class="btn btn-md btn-info" data-toggle="modal" data-target="#city_edit_Modal"><?php echo $language['edit_btn']; ?></button>
													<?php } ?>
												</td>
											</tr>
									<?php $t++; 
									}
									?>
								</tbody>
							</table>
							<?php
			                if(isset($_GET['page']))
			                {
			                    $select=$_GET['page'];
			                }
			                else
			                {
			                    $select=1;
			                }
			                
			                  $url="city.php?";  
			                
			               
			                echo pagination($getTotalcity,10,$select,$url);
			            	?>
							</div>
							<?php 
							}else
							{
								echo "Data not Found";
							}
							?>
                        </div>
                    </div>
                </div>
			</div>
        </div>
    </div>
</div>
<script>
function myFunction(city_edit_id) {
	jQuery.ajax({
	type: 'post',
	url: 'ajax/edit_city.php',
	data:'city_edit_id='+city_edit_id,
	
	
	success: function (response) {
		
	jQuery("#edit_city_form").html(response);
	
 }
 });
	
}
</script>
  <?php require_once('footer_link.php'); ?> 