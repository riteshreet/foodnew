<?php 
session_start();
 require_once('connection.php'); 

if(isset($_POST['formData']))
{
 $formdata = $_POST['formData'];
echo $formdata;

?>
	<select>
		<option disabled selected value> -- select an option -- </option>
		 <?php
			$menu_sql = "SELECT * FROM `food_menu` where category='".$formdata."'";
			$menu_result = $conn->query($menu_sql);
			if ($menu_result->num_rows > 0)
			{
			while($menu_row = $menu_result->fetch_assoc()) 
		{ ?>
			
			<option value="<?php echo  $menu_row["id"]; ?>"><?php echo  $menu_row["menu_name"]; ?></option>

		<?php }
		}
		?>
	</select>

<?php
} 
///////	
if(isset($_POST['select_currency']))
{
 $select_currency = $_POST['select_currency'];
		$sqll = "SELECT * FROM `food_user` where email='".$_SESSION['useremail']."'";
		$resultt = $conn->query($sqll);
		$total_order_amt = $resultt->fetch_assoc();
		echo $sq = "UPDATE `food_user` SET `currency`='".$select_currency."' WHERE `currency`='".$total_order_amt['currency']."'";;
		$conn->query($sq);
}

////
if(isset($_POST['id']))
{
	$id = $_POST['id'];
	$total_amt_sum=0;
?>
<div>
	<div class="container">
			<?php		
			$sql_cur = "SELECT * FROM `food_user`";
			$cur = $conn->query($sql_cur);
			$cursim = $cur->fetch_assoc();
			
			$set_order_sql = "SELECT * FROM `set_order_detail` where id='".$id."'";
			$resultt = $conn->query($set_order_sql);
			$set_order_row = $resultt->fetch_assoc();
			
			$string1 = $cursim['currency'];
			$val = explode("-",$string1);
			if($cursim['currency'] != "")
				{
					 $cur = $val[1]; 
				}
				else
				{
					 $cur = "$";
				}
				
			?>	
			<div class="modal-header">
				<h5 class="modal-title">Order No:&nbsp;<?php echo $set_order_row['id']; ?>&nbsp;-&nbsp;</h5>
				<h5  class="modal-title" id="myamt"></h5><h5  class="modal-title">
				<?php echo $cur; ?>
				</h5>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
<style>
.bill_tbl
{
	border-top:0px!important;
	padding:0.35rem!important;
}
</style>
		<?php
			$sql = "SELECT * FROM `app_user` where id='".$set_order_row['user_id']."'";
			$result = $conn->query($sql);
			while($user = $result->fetch_assoc()) 
				{ ?>
			<h5 style="border-bottom:1px rgba(0,0,0,.2) solid;padding:6px 0px;">Person Detail</h5> 
			
					<div><b><?php echo  $user["name"]; ?></b></div>
					<div><?php echo  $user["mob_number"]; ?></div> 
					<div><?php date_default_timezone_set('Asia/Kolkata'); echo $date = date('y-m-d h:i:s'); ?></div>
					<div style="padding-right:120px;"><?php echo  $user["address"]; ?></div> </br>
					<div>Payment Type : <?php echo  $user["payment_type"]; ?></div>
					<div>Notes : <?php echo  $user["notes"]; ?></div></br>
				</div>
		<?php 	} ?>
		
		
		<h5>Order Detail</h5> 				
			<table class="table">
				<tbody>
					<tr>
						<th>Item Name</th>
						<th>Item Qty</th>
						<th>Price</th>
						<th>Total Price</th>
					</tr>
					
					<?php 
						$sqll = "SELECT * FROM `fooddelivery_food_desc` where set_order_id = '".$id."'";
						$result = $conn->query($sqll);
							foreach($result as $item) 
							{ 
					?>		
						<tr>
							<?php 
							$sql = "SELECT * FROM `food_menu` where id = '".$item["item_id"]."'";
							$result_ingredients = $conn->query($sql);
							foreach($result_ingredients as $menu_items) 
							{ ?>
								<td>
									<b><?php echo $menu_items['menu_name']; ?></b></br>
									<?php   }
									
										$sqll_inte_inner = "SELECT * FROM `food_ingredients` where id IN(".$item["ingredients_id"].")";
										$result_inte_inner = $conn->query($sqll_inte_inner);
										if($result_inte_inner == ''){
										?>
										No Ingredients 
										<?php	
										}else{
										foreach($result_inte_inner as $item_inte_inner) 
										{
											echo $item_inte_inner['item_name']."</br>";
										} 
									}?> 
								</td>
							
								<td><b><?php echo $item["item_qty"] ?></b></td>
								<td>
									<b><?php echo $menu_items['price'].$cur; ?> </b></br>
									<?php
									$sqll_inte_inner = "SELECT * FROM `food_ingredients` where id IN(".$item["ingredients_id"].")";
										$result_inte_inner = $conn->query($sqll_inte_inner);
										if($result_inte_inner == ''){

										}else{
										foreach($result_inte_inner as $item_inte_inner) 
										{	
											if($item_inte_inner['price'] == 0)
											{
												echo "---</br>";
											}
											else
											{
												echo $item_inte_inner['price'] . $cur."</br>";
											}
										}
										} ?> 
								</td>
								<td><?php echo $item["ItemTotalPrice"] . $cur ?></td>
						</tr>
						
							<?php } ?>
					
						<script>
						jQuery("#myamt").html(<?php echo $set_order_row['total_price']; ?>);
					</script>
				</tbody>
			</table>
		<a  class="btn btn-info" target="_blank" href="printe.php?id=<?php echo $set_order_row['id']; ?>">Print</a> 
	</div>

</div>

<?php 
}
///////////
if(isset($_POST['city_edit_id']))
{ 
$city_edit_id = $_POST['city_edit_id'];
$sql_cityname = "SELECT * FROM `food_city` where id='".$city_edit_id."'";
$result_cityname = $conn->query($sql_cityname);
$city_name = $result_cityname->fetch_assoc();

?>
	<form action="" method="post">
		<div class="form-group">
			<label>City</label>
			<input type="text" class="form-control" placeholder="City" name="edit_city" value="<?php echo $city_name['city_name']; ?>" >
		</div>
		<input type="hidden" name="city_edit_id"  value="<?php echo $city_edit_id; ?> ">
		
		<div class="col-md-12">
			<div class=" col-md-6">
			<input type="submit" name="edit_city_submit"  class="btn btn-primary btn-md form-control" value="Edit">
			</div>
		
			<div class=" col-md-6">
				<input type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="Close">
			</div>
		</div>
	</form>
<?php		
}
//////////////
if(isset($_POST['cat_edit_id']))
{ 
	$cat_edit_id = $_POST['cat_edit_id'];
	$sql_catname = "SELECT * FROM `food_category` where id='".$cat_edit_id."'";
	$result_catname = $conn->query($sql_catname);
	$cat_data = $result_catname->fetch_assoc();
	
?>

	<form name="menu_form_category" action="" method="post" enctype="multipart/form-data">
		<div class="form-group">
			<label>Category Name</label>
			<input type="text" class="form-control" placeholder="User Name" name="cat_name" value="<?php echo $cat_data['cat_name']; ?>" >
		</div>
		<div class="form-group">
			<label>Category Icon</label>
			<img id="blahh"  class="img-fluid" src="http://192.168.1.117:8080/king_burger_admin/images/menu_cat_icon/<?php echo  $cat_data["cat_icon"]; ?>" width="100px">
			<input type="file" class="form-control"  name="file">
		</div>
		
		<input type="hidden" name="cat_edit_id"  value="<?php echo $cat_edit_id; ?> ">
		<input type="hidden" name="cat_old_icon"  value="<?php echo $cat_data["cat_icon"];?>">
		
		<div class="col-md-12">
			<div class="col-md-6">
				<input type="submit" name="edit_menu_cat"  class="btn btn-primary btn-md form-control" value="Edit">
			</div>
			<div class="col-md-6">
				<input type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="Close">
			</div>
		</div>
	</form>
<?php
}
//////////
if(isset($_POST['menuitem_edit_id']))
{ 
	$menuitem_edit_id = $_POST['menuitem_edit_id'];
	$sql_menuitem = "SELECT * FROM `food_menu` where id='".$menuitem_edit_id."'";
	$result_menuitem = $conn->query($sql_menuitem);
	$menuitem_data = $result_menuitem->fetch_assoc();
	
	$sql_cat = "SELECT * FROM `food_category` where id='".$menuitem_data["category"]."'";
	$result_cat = $conn->query($sql_cat);
	$cat_data = $result_cat->fetch_assoc();
	
?>
	<form name="menu_form_item" action="" method="post" enctype="multipart/form-data">
                        <div class="form-group">
							<label>Select Category</label></br>
							<select name="item_category" class="form-control" required >
								<option disabled selected value> -- select an option -- </option>
									<?php
										$sql = "SELECT * FROM `food_category`";
											$result = $conn->query($sql); ?>
										<option selected value="<?php echo  $cat_data["id"]; ?>"><?php echo  $cat_data["cat_name"]; ?></option>
										<?php
												while($cat_row = $result->fetch_assoc()) 
												{ ?>
													<option value="<?php echo  $cat_row["id"]; ?>"><?php echo  $cat_row["cat_name"]; ?></option>
										<?php } ?>
							</select>
                   	
						</div>
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" placeholder="Item Name"  name="item_name" value="<?php echo $menuitem_data['menu_name']; ?>" required >
                        </div>
						<div class="form-group">
                            <label>Description</label>
							<textarea class="form-control" placeholder="Description" name="item_description" required><?php echo $menuitem_data['description']; ?></textarea>
                        </div>
						 <div class="form-group">
                            <label>Price</label>
                            <input type="text" class="form-control" placeholder="Price" name="item_price" value="<?php echo $menuitem_data['price']; ?>" required>
                        </div>
						 <div class="form-group">
                            <label>Select Image</label>
							<img class="img-fluid" src="http://192.168.1.117:8080/king_burger_admin/images/menu_item_icon/<?php echo $menuitem_data['menu_image']; ?>" width="100px">
                            <input type="file" class="form-control" placeholder="User Name" name="file" >
                        </div>
						<input type="hidden" name="menuitem_old_icon"  value="<?php echo $menuitem_data['menu_image'];?>">
						<input type="hidden" name="menuitem_edit_id"  value="<?php echo $menuitem_edit_id; ?> ">
						
                       
                         <div class="col-md-12">
							<div class="col-md-6">
								<input type="submit" name="edit_menu_item"  class="btn btn-primary btn-md form-control"  value="Edit">
							</div>
							<div class="col-md-6">
								<input type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="Close">
							</div>
						</div>
						 
					</form>
<?php
}

if(isset($_POST['ingre_edit_id']))
{
	$ingre_edit_id = $_POST['ingre_edit_id'];
	$sql_ingr = "SELECT * FROM `food_ingredients` where id='".$ingre_edit_id."'";
	$result_ingr = $conn->query($sql_ingr);
	$ingredients = $result_ingr->fetch_assoc();
	
	$sql_cat = "SELECT * FROM `food_category` where id='".$ingredients["category"]."'";
	$result_cat = $conn->query($sql_cat);
	$cat_data = $result_cat->fetch_assoc();
	
	$sql_menu_id = "SELECT * FROM `food_menu` where id='".$ingredients["menu_id"]."'";
	$result_menu = $conn->query($sql_menu_id);
	$menu_data = $result_menu->fetch_assoc();
	?>
	<form name="menu_form_item" action="" method="post" enctype="multipart/form-data">
		<label>Select Menu Category</label></br>
		<div class="form-group">
			<select  name="ingredients_cat" id="Select" onchange="Function()" class="form-control" required>
				<option selected value="<?php echo  $cat_data["id"]; ?>"><?php echo  $cat_data["cat_name"]; ?></option>
			 <?php
				$sql = "SELECT * FROM `food_category`";
				$result = $conn->query($sql);
					
				while($cat_row = $result->fetch_assoc()) 
				{ ?>
					<option value="<?php echo  $cat_row["id"]; ?>"><?php echo  $cat_row["cat_name"]; ?></option>
		  <?php } ?>
			</select>
			
		</div>
		<label>Select Menu Item</label></br>
		<div class="form-group">
			<select name="ingredients_menu" id="submit_menu_name" class="form-control" required >
				<option selected value="<?php echo  $menu_data["id"]; ?>"><?php echo  $menu_data["menu_name"]; ?></option>
			</select>
		</div>

		<label>Item Name</label>
		<div class="form-group">
		   <input type="text" class="form-control" placeholder="Item Name"  name="ingredients_item" value="<?php echo  $ingredients["item_name"]; ?>" required  >
		</div>
		
		<label>Type</label>
		<div class="form-group">
			<div class="radio">
			<?php
				if($ingredients["price"]==0)
				{ ?>
					<label><input value="1" type="radio" onclick="javascript:yesnoChecks();" name="ingredients_type" id="yesChecks" >&nbsp;Paid</label>
					&nbsp;&nbsp;&nbsp;&nbsp;
					<label><input value="0" type="radio" onclick="javascript:yesnoChecks();" name="ingredients_type" id="yesChecks" checked >&nbsp;Free</label>
			<?php	}
				else
				{ ?>
					<label><input value="1" type="radio" onclick="javascript:yesnoChecks();" name="ingredients_type" id="yesChecks" checked >&nbsp;Paid</label>
					&nbsp;&nbsp;&nbsp;&nbsp;
					<label><input value="0" type="radio" onclick="javascript:yesnoChecks();" name="ingredients_type" id="yesChecks" >&nbsp;Free</label>
			<?php 	}
			?>
			
			</div>
		</div>

		<?php 
		if($ingredients["price"] == 0)
		{ ?>
			<div class="form-group">
			<div id="ifYess" style="display:none;">
			<label>Item Price</label>
				<input type="text" id="myTextt" value="<?php echo $ingredients["price"]; ?>" class="form-control" placeholder="Item Price"  name="ingredients_price" required  >
			</div>
		</div>
	<?php	}
		else
		{ ?>
			<div class="form-group">
			<div id="ifYess" style="display:block;">
			<label>Item Price</label>
				<input type="text" id="myTextt" value="<?php echo $ingredients["price"]; ?>" class="form-control" placeholder="Item Price"  name="ingredients_price" required  >
			</div>
		</div>
	<?php	}
		?>
		
		<input type="hidden" name="ingre_edit_id"  value="<?php echo $ingre_edit_id; ?> ">
		
		 <div class="col-md-12">
			<div class="col-md-6">
				<input type="submit" name="edit_ingredients"  class="btn btn-primary btn-md form-control" value="Edit">
			</div>
			<div class="col-md-6">
				<input type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="Close">
			</div>
		</div>
	</form>
<?php	
}
?>



