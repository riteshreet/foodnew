<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->

<?php
@session_start();
if(!isset($_SESSION['uid'])){
    echo "<script>window.location='index.php'</script>";
    session_destroy();
}
include_once('classes/DeliveryboyClass.php');
require_once('header_link.php'); 
include_once('classes/Utility.php');
include_once('language/lang_en.php');
require_once('side_menu.php');
include_once('pagination.php');
$page_limit=10;
if (isset($_GET['page'])) {
  $page=$_GET['page'];
}
else {
  $page=1;
}
if ($page=='' || $page==1) {
  $page1=0;
}
else{
  $page1=($page*$page_limit)-$page_limit;
}
if(isset($_GET['serach']) && $_GET['serach'] != ""){
	$row=DeliveryboyClass::getallboy_serach($_GET['serach'],$page1,$page_limit);
	$getTotalboy=DeliveryboyClass::getTotalboy_serach($_GET['serach']);  
}else{
	$row=DeliveryboyClass::getallboy($page1,$page_limit);
	$getTotalboy=DeliveryboyClass::getTotalboy();  	
} 
?> 
<div id="right-panel" class="right-panel">
	<?php require_once('header.php'); ?> 
        <!-- Header-->
        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo $language['delivery_boy']; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active"><?php echo $language['delivery_boy']; ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
<?php
if(isset($_POST["del_boy_data"]))
{
	$objDeliveryboy=new DeliveryboyClass();
	$objDeliveryboy->name = $_POST['del_boy_name'];
	$objDeliveryboy->mobile_no = $_POST['del_boy_mobileno'];
	$objDeliveryboy->email = $_POST['del_boy_email'];
	$objDeliveryboy->password = $_POST['del_boy_password'];
	$objDeliveryboy->vehicle_no = $_POST['del_boy_vehicleno'];
	$objDeliveryboy->vehicle_type = $_POST['del_boy_vehicle_type'];
	date_default_timezone_set('Asia/Kolkata');
	$objDeliveryboy->create_at = date('y-m-d h:i:s');
	$objMessage=DeliveryboyClass::insertNewBoy($objDeliveryboy);                   
    if ($objMessage->status==1) { 
     
      echo "<script>window.location.href='delivery_boy.php';</script>";
    }
    else{
        echo "<script>window.location.href='delivery_boy.php';</script>";
    }
	
}

if(isset($_GET['delivery_boy_id']))
	{
		$delivery_boy_id = $_GET['delivery_boy_id'];
		$delivery_boy__sql = mysqli_query($conn,"DELETE FROM `food_delivery_boy` WHERE `id`=".$delivery_boy_id."");
	
		echo "<script>window.location.href='delivery_boy.php';</script>";
	}
?>
		
<div class="content mt-3">
	<div class="animated">
		<div class="breadcrumbs">  
            <div class="page-header float-left">
                <div class="page-title">
                    <h1><button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#myModal"><?php echo $language['add_delivery_boy']; ?></button></h1>
                </div>
            </div>
        </div>
		<div class="modal fade" id="myModal" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title"><?php echo $language['add_delivery_boy']; ?></h5>
							<button type="button" class="close" data-dismiss="modal">&times;</button>
						</div>
						<div class="modal-body">
							<form action="" method="post" enctype="multipart/form-data">
								<div class="form-group">
									<label><?php echo $language['name']; ?></label>
									<input required="" type="text" class="form-control" placeholder="<?php echo $language['name']; ?>" name="del_boy_name">
								</div>
								
								<div class="form-group">
									<label><?php echo $language['contact_no']; ?></label>
									<input required="" type="text" class="form-control" placeholder="<?php echo $language['contact_no']; ?>" name="del_boy_mobileno" >
								</div>
								
								<div class="form-group">
									<label><?php echo $language['email']; ?></label>
									<input required="" type="email" class="form-control" placeholder="<?php echo $language['email']; ?>" name="del_boy_email" >
								</div>
								
								<div class="form-group">
									<label><?php echo $language['password']; ?></label>
									<input required="" type="password" class="form-control" placeholder="Password" name="del_boy_password" >
								</div>
								
								<div class="form-group">
									<label><?php echo $language['vehicle_no']; ?></label>
									<input required="" type="text" class="form-control" placeholder="<?php echo $language['vehicle_no']; ?>" name="del_boy_vehicleno" >
								</div>
								
								<div class="form-group">
									<label><?php echo $language['vehicle_type']; ?></label>
									<input required="" type="text" class="form-control" placeholder="<?php echo $language['vehicle_type']; ?>" name="del_boy_vehicle_type" >
								</div>
								
								<div class="col-md-12">
									<div class="col-md-6">
										<input required="" type="submit" name="del_boy_data" class="btn btn-primary btn-md form-control" value="<?php echo $language['add_btn']; ?>">
									</div>
									<div class="col-md-6">
									<input required="" type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="<?php echo $language['close_btn']; ?>">
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
		
		 <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
					<div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            
                        	<div class="col-sm-8">
				                <div class=" float-left">
				                   	<strong class="card-title"><?php echo $language['data_table']; ?></strong> 
				                </div>
				            </div>
				            <div class="col-sm-4">
				                <div class="p">
				                	<div class="row">
				                		<form method="get">
				                		<div class="col-md-8">
				                			<?php if(isset($_GET['serach'])){
				                			?>
				                			<input  required="" value="<?php echo $_GET['serach']?>" type="text" name="serach" class="form-control">
				                			<?php
				                			} else { ?>
				                    		<input placeholder="Delivery boy name" required="" type="text" name="serach" class="form-control">
				                    		<?php } ?>
				                    	</div>
				                    	<div class="col-md-2">
				                    		<?php if(isset($_GET['serach'])){
				                    		?>
				                    		<a href="delivery_boy.php" class="btn btn-primary btn-md"><?php echo $language['reset'];?></a>
				                    		<?php
				                    		} else { ?>
				                    		<button class="btn btn-primary btn-md" type="submit"><?php echo $language['search_btn'];?></button>
				                    		<?php } ?>
				                    	</div>
				                    	</form>
				                	</div>
				                </div>
				            
                        </div>
                        </div>
                        <div class="card-body">
                       	 	<?php if ($row)
							{ 
							?>
		                  	<table  class="table table-striped table-bordered">
		                    <thead>
		                      <tr>
								<th>#</th>
		                        <th><?php echo $language['name']; ?></th>
		                        <th><?php echo $language['contact_no']; ?></th>
								<th><?php echo $language['email']; ?></th>
								<th><?php echo $language['vehicle_no']; ?></th>
		                        <th><?php echo $language['vehicle_type']; ?></th>
								<th><?php echo $language['created_at']; ?></th>
		                        <th><?php echo $language['action']; ?></th>
		                      </tr>
		                    </thead>
		                    <tbody>
						        <?php
						        $t=1;
									for($i=0;$i<count($row);$i++) 
									{ ?>
											<tr>
												<td><?php echo  $t; ?></td>
												<td><?php echo  $row[$i]->name; ?></td>
												<td><?php echo  $row[$i]->mobile_no; ?></td>
												<td><?php echo  $row[$i]->email; ?></td>
												<td><?php echo  $row[$i]->vehicle_no; ?></td>
												<td><?php echo  $row[$i]->vehicle_type; ?></td>
												<td><?php echo  $row[$i]->create_at; ?></td>
												<td>
													<?php if($GLOBALS['button'] == 'YES') { ?>
													<a class="btn btn-md btn-danger " href="" onClick="return confirm('This function is currently disable as it is only a demo website, in your admin it will work perfect')"><?php echo $language['delete_btn']; ?></a>
													
													<?php } else { ?>
													<a  href="delivery_boy.php?delivery_boy_id=<?php echo $row[$i]->id; ?>" onclick="return confirm('Are you sure you want to delete?')" class="btn btn-md btn-danger "><?php echo $language['delete_btn'];?></a>
													<?php } ?>
												</td>
											
											</tr>
									<?php $t++; }
								?>
					        </tbody>
		                  </table>
		                  <div class="">
							<?php
			                if(isset($_GET['page']))
			                {
			                    $select=$_GET['page'];
			                }
			                else
			                {
			                    $select=1;
			                }
			                if(isset($_GET['serach'])){
			                   $url="delivery_boy.php?serach=".$_GET['serach']."&"; 
			                }else{
			                  $url="delivery_boy.php?";  
			                }
			               
			                echo pagination($getTotalboy,10,$select,$url);
			            	?>
							</div>
							<?php 
							}else
							{
								echo "Data not Found";
							}
							?>
                        </div>
                    </div>
                </div>
  			</div>
            </div><!-- .animated -->
        </div><!-- .content -->
</div><!-- /#right-panel -->

  <?php require_once('footer_link.php'); ?> 