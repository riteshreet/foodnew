<?php

if (isset($_SESSION['uid'])) {
  $id = $_SESSION['uid'];
}
else {
  header('location:../index.php');
} ?>
