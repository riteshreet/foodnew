<?php
$exist = "your mobile number already ragister";
$success = "your mobile number succefully ragister";
$input = "enter your mobile number";
$data = "enter your data perfectly";
$tokan_success = "your data succefully insert";
$tokan_update = "your data succefully updated";
$order_submit = "your order succefully submited";
$error = "Something went wrong";
$picked = "Order has been picked";
$complete = "Order has been delivered";
$invalid = "Invallid Email and Password";
$data_not_found = "No record Found";
$today_order = "Today You have no any new order";
$cancel = "Order has been cancelled";
$token_success = "Registered";
?>