<?php

require_once('../classes/Utility.php');
include('array_message.php');
$arrRecord = array();

if (isset($_REQUEST["deliverboy_id"])) {

        $sql = mysqli_query($conn,"SELECT * FROM food_delivery_boy where id='".$_REQUEST['deliverboy_id']."'");
        

        $rows = mysqli_fetch_array($sql);

            $result[] = array(
                "name" => $rows['name'],
                "mobile_no" => $rows['mobile_no'],
                "email" => $rows['email'],
                "vehicle_no" => $rows['vehicle_no'],
                "vehicle_type" => $rows['vehicle_type']
            );

        if (isset($result)) {
            if (!empty($result)) {
                $arrRecord['success'] = "1";
                $arrRecord['order'] = $result;
            } else {
                $arrRecord['success'] = "0";
                $arrRecord['order'] = $data_not_found;
            }
        } else {
            $arrRecord['success'] = "0";
            $arrRecord['order'] = $data_not_found;
        }
    } else {
        $arrRecord['success'] = "0";
        $arrRecord['order'] = $data;
    }
    echo json_encode($arrRecord);
    //echo '<pre>',print_r($arrRecord,1),'</pre>';
 ?>