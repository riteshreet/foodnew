<?php
require_once('../classes/Utility.php');
require_once('array_message.php'); 

if (
    isset($_POST['user_id']) && $_POST['user_id'] != "" &&
    isset($_POST['name']) && $_POST['name'] != "" &&
    isset($_POST['email']) && $_POST['email'] != "" &&
    isset($_POST['address']) && $_POST['address'] != "" &&
    isset($_POST['payment_type']) && $_POST['payment_type'] != "" &&
    isset($_POST['notes']) && $_POST['notes'] != "" &&
    isset($_POST['city']) && $_POST['city'] != "" &&
    isset($_POST['food_desc']) && $_POST['food_desc'] != "" &&
    isset($_POST['total_price']) && $_POST['total_price'] != "" &&
    isset($_POST['latlong']) && $_POST['latlong'] != "" &&
    isset($_POST['token_id']) && $_POST['token_id'] != ""
    )
{
    $user_id = $_POST['user_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $payment_type = $_POST['payment_type'];
    $notes = $_POST['notes'];
    $city = $_POST['city'];
    $food_desc = $_POST['food_desc'];
    $total_price = $_POST['total_price'];
    $latlong = $_POST['latlong'];
    $token_id = $_POST['token_id'];
    date_default_timezone_set('Asia/Kolkata');
    $date =  date('d-m-Y H:i');

     mysqli_set_charset( $conn, 'utf8');
    // $sql_update = mysqli_query($conn,"UPDATE `app_user` SET `name`= '$name' ,`email`= '$email' ,`address`= '$address' ,`payment_type`= '$payment_type' ,`notes`= '$notes' ,`city`= '$city' WHERE `id`= '".$user_id."'");

    $sql_update=mysqli_query($conn,"UPDATE `food_tokandata` SET `user_id`='".$user_id."' WHERE token='".$token_id."'");

    $sql = "INSERT INTO `set_order_detail`(`id`, `user_id`, `total_price`, `order_placed_date`, `order_status`, `preparing_date_time`, `preparing_status`, `assign_date_time`, `assign_status`, `dispatched_date_time`, `dispatched_status`, `delivered_date_time`, `delivered_status`, `is_assigned`,`latlong`,`name`,`address`,`email`,`payment_type`,`notes`,`city`,`notify`) VALUES (NULL,'".$user_id."','".$total_price."','".$date."','0','','','','','','','','','','".$latlong."','".$name."','".$address."','".$email."','".$payment_type."','".$notes."','".$city."','1')";
    $res = mysqli_query($conn,$sql);
	$last_id = mysqli_insert_id($conn);
	
	$sql_order_response = "INSERT INTO `food_order_response`(`id`, `order_id`, `desc`) VALUES (0,'".$last_id."','".$food_desc."')";
        $res_order_response = mysqli_query($conn,$sql_order_response);

	$datadesc = json_decode($food_desc, true);
	$Order = $datadesc['Order'];
	if (is_array($Order) || is_object($Order))
{
    foreach($Order as $val)
        {
            $deviceIds = array();
            //print_r($Order);
            foreach ($val['Ingredients'] as $item) {
                $deviceIds[] = $item['id'];
            }
            $str = implode(',', $deviceIds);
            //print_r($str); exit();

            $sql_qry = "INSERT INTO fooddelivery_food_desc(set_order_id,item_id,item_qty,ItemTotalPrice,item_amt,ingredients_id) VALUES('$last_id','".$val['ItemId']."', '".$val['ItemQty']."','".$val['ItemTotalPrice']."' ,'".$val['ItemAmt']."','".$str."')";
            $qry = mysqli_query($conn,$sql_qry);
        }
}
    if (isset($data)) {
            if (!empty($data)) {
                $arrRecord['success'] = "Order Book Successfully";
                $arrRecord['order_details'] = $order_submit;
                $arrRecord['order_id']=$last_id;
            } else {
                $arrRecord['success'] = "0";
                $arrRecord['order_details'] = $data_not_found;
            }
        } else {
            $arrRecord['success'] = "0";
            $arrRecord['order_details'] = $data_not_found;
        }        
} else {
         $arrRecord['data']['success'] = 0;
        $arrRecord['data']['order_details'] = $data;
}
echo json_encode($arrRecord);
?>