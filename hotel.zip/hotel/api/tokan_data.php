<?php 
require_once('../classes/Utility.php');
require_once('array_message.php'); 
$record = array();
 if(isset($_GET['token']) && ($_GET['type']) )
 {
	$token = $_GET['token'];	
	$type = $_GET['type'];
	 if($token)
	 {
		$sql = "INSERT INTO `food_tokandata`(`id`, `token`, `type`, `user_id`, `delivery_boyid`) VALUES (NULL,'".$token."','".$type."','','')";
		$result = $conn->query($sql);
		$record['success'] = "1";
		$record['register'] = $token_success;
	 }
}
 else
 {
	 $record['success'] = "0";
	 $record['register'] = $data;
 }

 echo json_encode(array("data"=>$record));
?>


					