<?php
require_once('../classes/Utility.php'); 
require_once('array_message.php'); 

if (isset($_POST['user_id']))
{
    $user_id = $_POST['user_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $payment_type = $_POST['payment_type'];
    $notes = $_POST['notes'];
    $city = $_POST['city'];
    $food_desc = $_POST['food_desc'];
    $total_price = $_POST['total_price'];
    date_default_timezone_set('Asia/Kolkata');
    $date = date('y-m-d h-i-s');


    $sql_update = mysqli_query($conn,"UPDATE `app_user` SET `name`= '$name' ,`email`= '$email' ,`address`= '$address' ,`payment_type`= '$payment_type' ,`notes`= '$notes' ,`city`= '$city' WHERE `id`= '$user_id'");

    $sql = "INSERT INTO `set_order_detail`(`id`, `user_id`, `total_price`, `order_placed_date`, `order_status`, `preparing_date_time`, `preparing_status`, `assign_date_time`, `assign_status`, `dispatched_date_time`, `dispatched_status`, `delivered_date_time`, `delivered_status`, `is_assigned`) VALUES (NULL,'".$user_id."','".$total_price."','".$date."','0','','','','','','','','','')";
    $res = mysqli_query($conn,$sql);
    $last_id = mysqli_insert_id($conn);

        $datadesc = json_decode($food_desc, true);
        $Order = $datadesc['Order'];
        foreach($Order as $val)
        {
            $sql_qry = "INSERT INTO fooddelivery_food_desc(set_order_id,item_id,item_qty,item_amt) VALUES('$last_id','".$val['ItemId']."', '".$val['ItemQty']."', '".$val['ItemAmt']."')";
            $qry = mysqli_query($conn,$sql_qry);
            // $last_ingre[] = mysqli_insert_id($conn);

            // $escaped_values = array_map('mysql_real_escape_string', array_values($last_ingre));
            // $values  = implode(", ", $escaped_values);

            foreach($val['Ingredients'] as $ing)
            {
                $sql_qry = "INSERT INTO food_order_ingredients(id,order_id,menu_id,ingredients_id) VALUES(null,'$last_id','".$ing['menu_id']."', '".$ing['id']."')";
                $qry = mysqli_query($conn,$sql_qry);
            }
        }

    if (isset($data)) {
            if (!empty($data)) {
                $arrRecord['success'] = "Order Book Successfully";
                $arrRecord['order_details'] = $data;
            } else {
                $arrRecord['success'] = "0";
                $arrRecord['order_details'] = $data_not_found;
            }
        } else {
            $arrRecord['success'] = "0";
            $arrRecord['order_details'] = $data_not_found;
        }        
} else {
         $arrRecord['data']['success'] = 0;
        $arrRecord['data']['order_details'] = $peramitter_not_set;
}
echo json_encode($arrRecord);
?>