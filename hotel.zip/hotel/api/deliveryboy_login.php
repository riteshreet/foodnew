<?php
require_once('../classes/Utility.php');
include('array_message.php');
$arrRecord = array();

if (isset($_REQUEST["email"]) && isset($_REQUEST["password"])) {
    $user_name = preg_match('/^[0-9a-z\W@.]*$/', strip_tags($_REQUEST["email"]));
    $user_pass = preg_match('/^[0-9a-z\W]*$/', strip_tags($_REQUEST["password"]));
    $token = $_REQUEST['token'];    
    $type = $_REQUEST['type'];

    if ($user_name && $user_pass) {
        $sql = mysqli_query($conn,"SELECT id, name, mobile_no, email, password, vehicle_no, vehicle_type FROM food_delivery_boy WHERE email='" . strip_tags($_REQUEST["email"]) . "' and password='" . strip_tags($_REQUEST["password"]) . "'");
        $rows = mysqli_fetch_array($sql);
	
        $result[] = array(
            "id" => $rows['id'],
            "name" => $rows['name'],
            "mobile_no" => $rows['mobile_no'],
            "email" => $rows['email'],
            "vehicle_no" => $rows['vehicle_no'],
            "vehicle_type" => $rows['vehicle_type']
        );
        $sqls = mysqli_query($conn,"SELECT token FROM food_tokandata WHERE token='" .$token. "'");
        $rowss = mysqli_fetch_array($sqls);
        if ($rowss == '') {
            $sql = mysqli_query($conn,"INSERT INTO `food_tokandata`(`id`, `token`, `type`, `user_id`, `delivery_boyid`) VALUES (NULL,'".$token."','".$type."','0','".$rows['id']."')");
        } else {
            $sql_update=mysqli_query($conn,"UPDATE `food_tokandata` SET `user_id`='0',`delivery_boyid`='".$rows['id']."' WHERE token='".$token."'");
                    
        }
        if ($rows > 0) {
            foreach ($rows as $row) {
                $arrRecord['data']['success'] = "1";
                $arrRecord['data']['login'] = $result;
            }
        } else {
            $arrRecord['data']['success'] = "0";
            $arrRecord['data']['login'] = $invalid;
        }      

    } else {
        $arrRecord['data']['success'] = "0";
        $arrRecord['data']['login'] = $data;
    }
   
} else {
    $arrRecord['data']['success'] = 0;
    $arrRecord['data']['login'] = $error;
}

echo json_encode($arrRecord);
?>