<?php

require_once('../classes/Utility.php');
include('array_message.php');
$arrRecord = array();
mysqli_set_charset($conn,"utf8");

if (isset($_REQUEST["user_id"])) {

        $sql = mysqli_query($conn,"SELECT user_id,id,total_price,address FROM set_order_detail WHERE user_id='" .$_REQUEST["user_id"] . "'");
        

        while ($rows = mysqli_fetch_array($sql))
        {
            
            $sql3=mysqli_query($conn,"SELECT id FROM app_user where id='".$rows['user_id']."'");
            $row3=mysqli_fetch_array($sql3);
            $result[] = array(
                "order_no" => $rows['id'],
                "total_amount" => $rows['total_price'],
                "order_id" => $rows['id'],
                "address"=>$rows['address']
            );
        }

        if (isset($result)) {
            if (!empty($result)) {
                $arrRecord['success'] = "1";
                $arrRecord['order'] = $result;
            } else {
                $arrRecord['success'] = "0";
                $arrRecord['order'] = $data_not_found;
            }
        } else {
            $arrRecord['success'] = "0";
            $arrRecord['order'] = $data_not_found;
        }
    } else {
        $arrRecord['success'] = "0";
        $arrRecord['order'] = $data;
    }
    echo json_encode($arrRecord);
    //echo '<pre>',print_r($arrRecord,1),'</pre>';
 ?>