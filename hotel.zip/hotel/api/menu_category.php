<?php 

 require_once('../classes/Utility.php');

$sql = "SELECT * FROM `food_category`";
$result = $conn->query($sql);

$temp_array = array();

while($data = $result->fetch_assoc())
{
	$temp_array[] = $data;
}
	echo json_encode(array("menu_category"=>$temp_array));

?>

			
