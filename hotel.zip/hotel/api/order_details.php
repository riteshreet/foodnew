<?php
require_once('../classes/Utility.php');
include('array_message.php');


if (@$_GET["order_id"] != '') {
    mysqli_set_charset( $conn, 'utf8');
    $query = mysqli_query($conn, "SELECT  fo.id as order_id,fo.total_price,fo.assign_date_time ,fo.cancel_date_time,fo.is_assigned,fo.assign_status,fo.order_placed_date,fo.preparing_date_time,fo.preparing_status,fo.dispatched_date_time,fo.dispatched_status,fo.delivered_date_time,fo.delivered_status,fo.order_status,fo.address,au.mob_number
        FROM set_order_detail fo 
        inner join app_user au on fo.user_id = au.id
        where fo.id='".$_GET['order_id']."'");

    $res = mysqli_fetch_array($query);

    $order_count = mysqli_query($conn,"SELECT set_order_id from fooddelivery_food_desc where set_order_id='".$_GET['order_id']."'");
    $count = mysqli_num_rows($order_count);
        if($res['order_status'] == '0'){
                $order_status = 'Activate';
            }
            elseif ($res['order_status']=='1') {
                $order_status='preparing';
            }
            elseif ($res['order_status']=='2') {
                $order_status='Rejected';
            }
            elseif ($res['order_status']=='3') {
                $order_status='Delivered';
            }
            elseif ($res['order_status']=='4') {
                $order_status='Delete';
            }
            elseif ($res['order_status']=='5') {
                $order_status='In Pickup';
            }
            elseif ($res['order_status']=='6') {
                $order_status='Cancelled';
            }
             
            if($res['order_placed_date'] != ''){
                $order_placed_date='Activate';
            }
            else{
                $order_placed_date='Deactivate';
            }
        if ($res['preparing_status'] == '1') {
            $preparing_status = 'Activate';
        } else {
            $preparing_status = 'Deactivate';
        }

        if ($res['dispatched_status'] == '1') {
            $dispatched_status = 'Activate';
        } else {
            $dispatched_status = 'Deactivate';
        }

        if ($res['delivered_status'] == '1') {
            $delivered_status = 'Activate';
        } else {
            $delivered_status = 'Deactivate';
        }

            {
                $order_details[] = array(
                    "item_order" => $count,
                    "address" => $res['address'],
                    "contact" => $res['mob_number'],
                    "total_price" => $res['total_price'],
                    "order_status" => @$order_status,
                    "place_status"=>$order_placed_date,
                    "order_placed_date" => $res['order_placed_date'],
                    "preparing_status" => $preparing_status,
                    "preparing_date_time" => $res['preparing_date_time'],
                    "dispatched_status" => $dispatched_status, 
                    "dispatched_date_time" => $res['dispatched_date_time'],
                    "delivered_date_time" => $res['delivered_date_time'],
                    "delivered_status" => $delivered_status,
                    "cancel_date_time" => $res['cancel_date_time']
                );
            }
            $query_name = mysqli_query($conn, "SELECT * from food_order_response WHERE order_id = '".$_REQUEST['order_id']."'");          

            $res_name = mysqli_fetch_array($query_name);
            $dest = $res_name['desc'];
            $datadesc = json_decode($dest, true);

            $str = $dest;
            $str = ltrim($str, '{"Order":');
            $r = rtrim($str,"}");
            $datadesc = json_decode($r, true);
            $order_details[0]['menu'] = $datadesc; 

        if (!empty($res)) {
            $arrRecord['success'] = "1";
            $arrRecord['order_details'] = $order_details;
        } else {
            $arrRecord['success'] = "0";
            $arrRecord['order_details'] = $data_not_found;
        }
    } else {
        $arrRecord['success'] = "0";
        $arrRecord['order_details'] = $data;
    }
    echo json_encode($arrRecord);
    //echo '<pre>',print_r($arrRecord),'</pre>';
?>