<?php

require_once('../classes/Utility.php');
include('array_message.php');
$arrRecord = array();

if (isset($_REQUEST["deliverboy_id"])) {
        $sql = mysqli_query($conn,"SELECT * FROM set_order_detail WHERE is_assigned='" .$_REQUEST["deliverboy_id"] . "'");           

        while ($rows = mysqli_fetch_array($sql))
        {

            $sql2 = mysqli_query($conn,"SELECT * FROM fooddelivery_food_desc WHERE set_order_id='" .$rows["id"] . "'");
            $rows2 = mysqli_num_rows($sql2);
            $date = $rows['order_placed_date'];

            if ($rows['order_status'] == '5') {
                $status = 'Order is preparing';
            } else if($rows['order_status'] == '3'){
                $status = 'Order is Dispatched';
            } else if ($rows['order_status'] == '4') {
                $status = 'Order is Delivered';
            }

            $dateTime  = $rows['assign_date_time'];
            $datefrom  = date("d-m-Y", strtotime($dateTime));

            $today = date('d-m-Y');
            $last_date = $datefrom;

            if ($today == $last_date) {
                $result[] = array(
                    "order_no" => $rows['id'],
                    "total_amount" => $rows['total_price'],
                    "items" => $rows2,
                    "date" => $date,
                    "status" => $status
                );
            } 
                        
        }
        
        if (isset($result)) {
            if (!empty($result)) {
                $arrRecord['success'] = "1";
                $arrRecord['order'] = $result;
            } else {
                $arrRecord['success'] = "0";
                $arrRecord['order'] = $error;
            }
        } else {
            $arrRecord['success'] = "0";
            $arrRecord['order'] = $today_order;
        }
    } else {
        $arrRecord['success'] = "0";
        $arrRecord['order'] = $data;
    }
    echo json_encode($arrRecord);
    //echo '<pre>',print_r($arrRecord,1),'</pre>';
 ?>