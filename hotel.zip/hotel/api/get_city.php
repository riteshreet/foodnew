<?php 
 require_once('../classes/Utility.php');
 include('array_message.php');
 $arrRecord = array(); 
	$sql = "SELECT * FROM `food_city`";
	$result = $conn->query($sql);

	$temp_array = array();

	while($data = $result->fetch_assoc())
	{
		$temp_array[] = $data;
	}
	if ($temp_array) {
		$arrRecord['data']['success'] = "1";
		$arrRecord['data']['city'] = $temp_array;
	} else {
		$arrRecord['data']['success'] = "0";
    	$arrRecord['data']['city'] = $data_not_found;
	}
	echo json_encode($arrRecord);
?>