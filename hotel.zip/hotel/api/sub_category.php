<?php 

 require_once('../classes/Utility.php');
	
	
	$sql = "SELECT * FROM `food_menu` where `category` = '".$_GET['category']."'";
	$result = $conn->query($sql);
	
	

	$temp_array = array();

	while($data = $result->fetch_assoc())
	{
		$temp_array[] = $data;
	}
	
	$url_id = $_GET['category'];

		if($url_id == NULL)
		{
			echo "Enter Parameter Id In URL";
		}
		else
		{
			echo json_encode(array("sub_category"=>$temp_array));
		}

?>