<?php 
require_once('../classes/Utility.php');
require_once('array_message.php'); 
$record = array();
 if(isset($_REQUEST['mobile_no']) != '' && isset($_REQUEST['token']) != '')
 {

	$mobile_no = $_REQUEST['mobile_no'];
	$token = $_REQUEST['token'];
	
	$mysql = mysqli_query($conn,"SELECT * FROM `app_user` where mob_number = '".$mobile_no."'");
	
	$myresult = mysqli_fetch_array($mysql);
	if($myresult)
	{
		$sql_update=mysqli_query($conn,"UPDATE `food_tokandata` SET `user_id`='".$myresult['id']."',`delivery_boyid`='0' WHERE token='".$token."'");
		$last_id['userid'] = $myresult['id'];
		$record['success'] = "1";
		$record['register'] = $last_id;
	}	 
	else
	{
		date_default_timezone_set('Asia/Kolkata');
		$date = date('y-m-d h-i-s');
		$sql = "INSERT INTO `app_user`(`mob_number`, `create_at`) VALUES('".$mobile_no."','".$date."')";
		
		$conn->query($sql);
		$user_id = $conn->insert_id;

		$last_id['userid'] = $user_id;

		$sql_update="UPDATE `food_tokandata` SET `user_id`='".$user_id."',`delivery_boyid`='0' WHERE token='".$token."'";
		//print_r($sql_update);
		$result_update = $conn->query($sql_update);
		$record['success'] = "1";
		$record['register'] = $last_id;
	}
}
 else
 {
	 $record['success'] = "0";
	 $record['register'] = $input;
 }

 echo json_encode(array("data"=>$record));
?>


					