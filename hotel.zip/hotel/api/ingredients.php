<?php 

 require_once('../classes/Utility.php');
include('array_message.php');
$arrRecord = array(); 
	if(isset($_GET['menu_id']))
	{
		$sql = "SELECT * FROM `food_ingredients` where `menu_id` = '".$_GET['menu_id']."'";
	
		$result = $conn->query($sql);
		$free_array = array();
		$paid_array = array();
		
		while($row = $result->fetch_assoc())
		{
			
			$dataa = array(
				'id'  => $row['id'],
				'category' => $row['category'],
				'item_name' => $row['item_name'],
				'type' => $row['type'],
				'price' => $row['price'],
				'menu_id' => $row['menu_id'],
			);
			if($row['type'] == '0')
			{
				$free_array[] = $dataa;
			}
			else
			{
			
				$paid_array[] = $dataa;
			}
		}
		
		if($paid_array == NULL && $free_array == NULL)
		{
			echo json_encode(array("Ingredients"=>[]));
		}
		else
		{
			echo json_encode(array("Ingredients"=>
			array(array("free"=>$free_array),
			array("paid"=>$paid_array))
			
			));
		}
	}	
	else
	{
		$arrRecord['data']['success'] = "0";
		$arrRecord['data']['ingredients'] = $data;
		echo json_encode($arrRecord);
	}
	
	
	?>

		