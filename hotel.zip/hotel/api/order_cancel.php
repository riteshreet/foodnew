<?php

require_once('../classes/Utility.php');
include('array_message.php');
$arrRecord = array();

if (isset($_REQUEST["order_id"])) {

    $order_id = $_REQUEST['order_id'];
    date_default_timezone_set("Asia/Calcutta");
	$date = date('d-m-Y H:i');
        $sql = mysqli_query($conn,"UPDATE `set_order_detail` SET `cancel_date_time`='".$date."',`order_status`= 6 WHERE `id`= '".$_REQUEST['order_id']."'");
        $res = mysqli_affected_rows($conn);
        if ($res > 0) {
                $arrRecord['success'] = "1";
                $arrRecord['order'] = $cancel;
            } else {
                $arrRecord['success'] = "0";
                $arrRecord['order'] = $data_not_found;
            }
        } else {
            $arrRecord['success'] = "0";
            $arrRecord['order'] = $data;
        }
    echo json_encode($arrRecord);
    //echo '<pre>',print_r($arrRecord,1),'</pre>';
 ?>