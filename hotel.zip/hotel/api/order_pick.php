<?php

require_once('../classes/Utility.php');
include('../order_message.php');
include('array_message.php');
$arrRecord = array();

if (isset($_REQUEST["order_id"])) {

    $order_id = $_REQUEST['order_id'];
    //Push Notification
    $order_user=mysqli_query($conn,"select * from set_order_detail WHERE `id`='".$order_id."'");
    $user=mysqli_fetch_array($order_user);
    $user_id=$user['user_id'];

    $querya=mysqli_query($conn,"select * from food_notification");
    $resa=mysqli_fetch_array($querya);
    $google_api_key=$resa['android_key'];
    $ios_api_key=$resa['ios_key'];

    $sendresult = array();
    $query=mysqli_query($conn,"select * from food_tokandata where type='android' AND user_id='".$user_id."'");
    $count = mysqli_num_rows($query);
    $reg_id = $res['token'];
    $massage = $pickorder_msg;
        
    if ($count) {

        $i      = 0;
        $reg_id = array();
        while ($res1 = mysqli_fetch_array($query)) {
            
            $reg_id[$i] = $res1['token'];
            $i++;
        }
         $registrationIds =  $reg_id ;
        
        $message = array(
            'message' => $massage,
            'title' => 'Order Status');

        $fields = array(
            'registration_ids'  =>  $registrationIds,
            'data'      => $message
        );

        $url = 'https://fcm.googleapis.com/fcm/send';

        $headers = array(
            'Authorization: key='.$google_api_key,// . $api_key,
            'Content-Type: application/json'
        );

        $json =  json_encode($fields);

        $ch = curl_init();
       
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$json);

        $result = curl_exec($ch);
        //print_r($result); exit();
        if ($result === FALSE){
                die('Curl failed: ' . curl_error($ch));
            }   

            curl_close($ch);
            $response=json_decode($result,true);
            //print_r($response); exit();
            if($response['success']>0)
            {
                $sendresult['android'] = $response['success'];
            }
            else
            {
               $sendresult['android'] = 0;
            }
    } else {
        $queryios=mysqli_query($conn,"select * from food_tokandata where type='Iphone' AND user_id='".$user_id."'");

        

         $i      = 0;
        $reg_id = array();
        while ($resios = mysqli_fetch_array($queryios)) {
            
            $resios[$i] = $resios['token'];
            $i++;
        }
         $registrationIds =  $reg_id ;

       

        $msg = array(
        'body'  => $massage,
        'title'     => "Notification",
        'vibrate'   => 1,
        'sound'     => 1,
        );

        $fields = array(
            'registration_ids'  => $registrationIds,
            'notification'      => $msg
        );
        
        $headers = array(
            'Authorization: key=' . $ios_api_key,
            'Content-Type: application/json'
        );

        $ch = curl_init();
        curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
        curl_setopt( $ch,CURLOPT_POST, true );
        curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
        curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
        curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
        $result = curl_exec($ch );

        if ($result === FALSE){
            die('Curl failed: ' . curl_error($ch));
        }   

        curl_close($ch);
        $response=json_decode($result,true);
        //print_r($response); exit();
        if($response['success']>0)
        {
            {
                $sendresult['ios'] = $response['success'];
            }
        }
        else
        {
           $sendresult['ios'] = 0;
        }
    }
    date_default_timezone_set("Asia/Calcutta");
	$date = date('d-m-Y H:i');
        $sql = mysqli_query($conn,"UPDATE `set_order_detail` SET order_status='3',dispatched_date_time='".$date."',dispatched_status='1' WHERE `id`='".$order_id."'");
        $res = mysqli_affected_rows($conn);
        if ($res > 0) {
                $arrRecord['success'] = "1";
                $arrRecord['order'] = $picked;
            } else {
                $arrRecord['success'] = "0";
                $arrRecord['order'] = $data_not_found;
            }
        } else {
            $arrRecord['success'] = "0";
            $arrRecord['order'] = $data;
        }
    echo json_encode($arrRecord);
    //echo '<pre>',print_r($arrRecord,1),'</pre>';
 ?>