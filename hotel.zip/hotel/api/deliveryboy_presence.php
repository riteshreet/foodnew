<?php

require_once('../classes/Utility.php');
include('array_message.php');
$arrRecord = array();

if (isset($_POST["status"])) {

    $attendance = $_POST['status'];
    $deliverboy_id = $_POST['deliverboy_id'];
        $sql = mysqli_query($conn,"UPDATE `food_delivery_boy` SET `attendance`='".$attendance."' WHERE id='".$deliverboy_id."'");

        if ($sql) {
                $arrRecord['data']['success'] = "1";
                $arrRecord['data']['presence'] = $attendance;
        } else {
            $arrRecord['data']['success'] = 0;
            $arrRecord['data']['presence'] = $error;
        }      

} else {
    $arrRecord['data']['success'] = 0;
    $arrRecord['data']['presence'] = $data;
}

echo json_encode($arrRecord);
 ?>