<?php
require_once('../classes/Utility.php');
include('array_message.php');
if (isset($_REQUEST["order_id"])) {
    $query = mysqli_query($conn, "SELECT od.total_price,od.order_placed_date,od.latlong,od.name,od.payment_type,od.address,au.mob_number from set_order_detail od 
        inner join app_user au on od.user_id = au.id
        WHERE od.id = '".$_REQUEST['order_id']."'");
    
    $res = mysqli_fetch_array($query);

    $latlong = $res['latlong'];
    $s_lat = explode(',', $latlong);
    @$send_latitude = $s_lat[0];
    @$send_longitude = $s_lat[1];

        $result[] = array(
            "order_amount" => $res['total_price'],
            "payment" => $res['payment_type'],
            "date" => $res['order_placed_date'],
            "address" => $res['address'],
            "customer_name" => $res['name'],
            "phone" => $res['mob_number'],
            "latitude" => $send_latitude,
            "longitude" => $send_longitude
        );

        $arrName = array();
        $query_name = mysqli_query($conn, "SELECT fd.set_order_id,fd.item_id , fd.item_qty , fd.item_amt , fd.ingredients_id, fs.id , fs.menu_name , fs.description from 
        fooddelivery_food_desc fd inner join food_menu fs on fd.item_id = fs.id
        WHERE fd.set_order_id = '".$_REQUEST['order_id']."'");

        while ($res_name = mysqli_fetch_array($query_name))
        {
            if (!empty($res_name['ingredients_id'])) {
                $sqll_inte_inner = mysqli_query($conn,"SELECT group_concat(item_name) as item_name FROM `food_ingredients` where id IN(".$res_name["ingredients_id"].") group by menu_id");
                $result_inte_inner = mysqli_fetch_array($sqll_inte_inner);
                $ingredients = $result_inte_inner['item_name'];
            } else {
                $ingredients = "";
            }
            $arrName[] = array(
                "name" => $res_name['menu_name'],
                "description" => $res_name['description'],
                "qty" => $res_name['item_qty'],
                "amount" => $res_name['item_amt'],
                "ingredients_id" => $ingredients
            );
        }

        $result[0]['item_name'] = $arrName;
        
        if (!empty($res)) {
                $arrRecord['success'] = "1";
                $arrRecord['Order'] = $result[0];
            } else {
                $arrRecord['success'] = "0";
                $arrRecord['Order'] = $data_not_found;
            }
        } else {
            $arrRecord['success'] = "0";
            $arrRecord['Order'] = $data;
        }
    echo json_encode($arrRecord);
    //echo '<pre>',print_r($arrRecord,1),'</pre>';
?>