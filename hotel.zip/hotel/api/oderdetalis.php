<?php

require_once('../classes/Utility.php');
include('array_message.php');
$arrRecord = array();
mysqli_set_charset($conn,"utf8");

if (isset($_REQUEST["order_id"])) {
        $sql = mysqli_query($conn,"SELECT user_id,id,total_price,order_status FROM set_order_detail WHERE id='" .$_REQUEST["order_id"] . "'");
        
        $query_name = mysqli_query($conn, "SELECT * from food_order_response WHERE order_id = '".$_REQUEST['order_id']."'");
            $res_name = mysqli_fetch_array($query_name);
            $dest = $res_name['desc'];
            $datadesc = json_decode($dest, true);

            $str = $dest;
            $str = ltrim($str, '{"Order":');
            $r = rtrim($str,"}");
            $datadesc = json_decode($r, true);

            $order_details[0]['menu'] = $datadesc;
            //print_r($datadesc);
        while ($rows = mysqli_fetch_array($sql))
        {
            if($rows['order_status'] == '0'){
                $order_status = 'Not Assign';
            }
            elseif ($rows['order_status']=='1') {
                $order_status='Assign Order';
            }
            elseif ($rows['order_status']=='2') {
                $order_status='Rejected';
            }
            elseif ($rows['order_status']=='3') {
                $order_status='Delivered';
            }
            elseif ($rows['order_status']=='4') {
                $order_status='Delete';
            }
            elseif ($rows['order_status']=='5') {
                $order_status='In Pickup';
            }
        }

        if ($res['preparing_status'] == '1') {
            $preparing_status = 'Activate';
        } else {
            $preparing_status = 'Deactivate';
        }
        if ($res['dispatched_status'] == '1') {
            $dispatched_status = 'Activate';
        } else {
            $dispatched_status = 'Deactivate';
        }

        if ($res['delivered_status'] == '1') {
            $delivered_status = 'Activate';
        } else {
            $delivered_status = 'Deactivate';
        }

            $sql3=mysqli_query($conn,"SELECT address,id,mob_number FROM app_user where id='".$rows['user_id']."'");
            $row3=mysqli_fetch_array($sql3);
            $result[] = array(
                "order_status" =>$order_status,

                "order_details" => $order_details,
                "total_price" => $rows['total_price'],
                "mob_number"=>$row3['mob_number'],
                "address"=>$row3['address']
            );
        }

        if (isset($result)) {
            if (!empty($result)) {
                $arrRecord['success'] = "1";
                $arrRecord['order'] = $result;
            } else {
                $arrRecord['success'] = "0";
                $arrRecord['order'] = $data_not_found;
            }
        } else {
            $arrRecord['success'] = "0";
            $arrRecord['order'] = $data_not_found;
        }
    } else {
        $arrRecord['success'] = "0";
        $arrRecord['order'] = $data;
    }
    echo json_encode($arrRecord);
    //echo '<pre>',print_r($arrRecord,1),'</pre>';
 ?>