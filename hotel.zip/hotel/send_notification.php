<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->

<?php 
@session_start();
if(!isset($_SESSION['uid'])){
   echo "<script>window.location='index.php'</script>";
    session_destroy();
}
include_once('classes/NotificationClass.php');
include_once('language/lang_en.php');
require_once('header_link.php');
include_once('pagination.php');
$page_limit=10;
if (isset($_GET['page'])) {
  $page=$_GET['page'];
}
else {
  $page=1;
}
if ($page=='' || $page==1) {
  $page1=0;
}
else{
  $page1=($page*$page_limit)-$page_limit;
}

$send=NotificationClass::getall($page1,$page_limit);
$getTotalcity=NotificationClass::getTotalnoti();   
?> 
<body>

<?php require_once('side_menu.php'); ?> 
       
    <!-- Left Panel -->

    <!-- Right Panel -->

	
	
    <div id="right-panel" class="right-panel">
	<?php require_once('header.php'); ?> 
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo $language['send_notification']; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active"><?php echo $language['send_notification']; ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

<?php
if(isset($_POST["send_notification"]))
{
   
    $query          = mysqli_query($conn, "select * from food_notification");
    $res            = mysqli_fetch_array($query);
    $google_api_key = $res['android_key'];
    $ios_api_key = $res['ios_key'];    
    // Notification Data
    
    $query2 = mysqli_query($conn, "select * from food_tokandata where type='android'");
    $i      = 0;
    $reg_id = array();
    while ($res1 = mysqli_fetch_array($query2)) {
        
        $reg_id[$i] = $res1['token'];
        $i++;
    }
    
    $massage = $_POST['send_message'];
    
    
   
        $title = "Notification";

        $message         = array(
            "title" => $title,
            "message" => $massage
        );
        
    
    $registrationIds = $reg_id;    
    
    $fields          = array(
        'registration_ids' => $registrationIds,
        'data' => $message,
    );

    $url             = 'https://fcm.googleapis.com/fcm/send';
    $headers         = array(
        'Authorization: key=' . $google_api_key, // . $api_key,
        'Content-Type: application/json'
    );

    $json            = json_encode($fields);
    
    $ch = curl_init();
    
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
    
    $result = curl_exec($ch);
   
    if ($result === FALSE) {
        die('Curl failed: ' . curl_error($ch));
    }
    
    curl_close($ch);
    $response = json_decode($result, true);
    


    $query_ios = mysqli_query($conn, "select * from food_tokandata where type='Iphone'");
    $i      = 0;
    $reg_id_ios = array();
    while ($res_ios = mysqli_fetch_array($query_ios)) {
        
        $reg_id_ios[$i] = $res_ios['token'];
        $i++;
    }
    
    $massage = $_POST['send_message'];

    $msg = array(
    'body'  => $massage,
    'title'     => "Notification",
    'vibrate'   => 1,
    'sound'     => 1,
    );
    $registrationIds = $reg_id_ios;
    $fields = array(
        'registration_ids'  => $registrationIds,
        'notification'      => $msg
    );

    $url             = 'https://fcm.googleapis.com/fcm/send';
    $headers         = array(
        'Authorization: key=' . $ios_api_key, // . $api_key,
        'Content-Type: application/json'
    );

    $json            = json_encode($fields);
    
    $ch = curl_init();
    
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
    
    $result = curl_exec($ch);
   
    if ($result === FALSE) {
        die('Curl failed: ' . curl_error($ch));
    }
    
    curl_close($ch);
    $response_ios = json_decode($result, true);


    if ($response['success'] > 0 || $response_ios['success'] > 0) {
       
        $insert = mysqli_query($conn, "INSERT INTO `food_send_notification`(`message`) VALUES ('".$massage."')");
            if ($insert) {
                
                $success = "Notification Sent";
            }
        } else {

            $fail = "Something Went Wrong";
        }
    }
    
?>  
		
 <div class="content mt-3">
            <div class="animated">
<!-- Trigger the modal with a button -->
  <div class="col-md-12">
  <button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#myModal"><?php echo $language['send_notification']; ?></button>
</div>

<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title"><?php echo $language['send_notification']; ?></h5>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
      <form name="menu_form_category" action="" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label><?php echo $language['message']; ?></label>
                            <input type="text" class="form-control" placeholder="Message" name="send_message" >
                        </div>
                       
                       
                       <div class="form-group">
							<input type="submit" name="send_notification"  class="btn btn-primary btn-md form-control" value="<?php echo $language['send_btn'] ?>">
						
						</div>
						<div class="form-group">
							
						  <input type="button" class="btn btn-secondary btn-md form-control" data-dismiss="modal" value="<?php echo $language['close_btn'] ?>">
						</div>
						 
                    </form>
</div></div></div></div>



            </div><!-- .animated -->
        </div><!-- .content -->
		
		 <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title"><?php echo $language['data_table']; ?></strong>
                        </div>
                        <div class="card-body">
                            <?php if($send) { ?>
                    <table  class="table table-striped table-bordered">
                    <thead>
                      <tr>
                        <th>#</th>
						<th><?php echo $language['message']; ?></th>
                       </tr>
                    </thead>
                    <tbody>
                        <?php
                		// $sql = "SELECT * FROM `food_send_notification`";
                		// $result = $conn->query($sql);
                       
                		if ($send)
                		{
                            $t = 1;
                			for($i=0;$i<count($send);$i++) 
                			{ ?>
                					<tr>
                					<td><?php echo  $t; ?></td>
                						<td><?php echo  $send[$i]->message; ?></td>
                					</tr>
                			<?php $t++; }
                		}
                		?>
			        </tbody>
                  </table>
                  <?php
                            if(isset($_GET['page']))
                            {
                                $select=$_GET['page'];
                            }
                            else
                            {
                                $select=1;
                            }
                            
                              $url="send_notification.php?";  
                            
                           
                            echo pagination($getTotalcity,10,$select,$url);
                            ?>
                            </div>
                            <?php 
                            }else
                            {
                                echo "Data not Found";
                            }
                            ?>
                        </div>
                    </div>
                </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->
		
		
    </div><!-- /#right-panel -->

  <?php require_once('footer_link.php'); ?> 